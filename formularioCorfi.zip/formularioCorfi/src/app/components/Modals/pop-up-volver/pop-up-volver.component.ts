import { Component } from '@angular/core';

@Component({
  selector: 'app-pop-up-volver',
  templateUrl: './pop-up-volver.component.html',
  styleUrls: ['./pop-up-volver.component.scss']
})
export class PopUpVolverComponent {

}
