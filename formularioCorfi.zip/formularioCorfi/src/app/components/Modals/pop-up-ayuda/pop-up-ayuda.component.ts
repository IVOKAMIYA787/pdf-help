import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pop-up-ayuda',
  templateUrl: './pop-up-ayuda.component.html',
  styleUrls: ['./pop-up-ayuda.component.scss'],
})
export class PopUpAyudaComponent {
  constructor(private router: Router) { }
  newForm() {
    localStorage.clear();
    this.router.navigate(['']);
    window.location.reload();
  }
}
