import {
  Component,
  AfterViewInit,
  EventEmitter,
  OnInit,
  Output,
  Input,
  OnChanges,
  ElementRef,
  ViewChild,
  SimpleChanges,
  DoCheck,
} from '@angular/core';
import { NgForm } from '@angular/forms';
import { formData } from 'src/app/utils/form.utils';
import { countries, Country } from 'countries-list';

import * as XLSX from 'xlsx';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import * as intlTelInput from 'intl-tel-input';
import { FormService } from 'src/app/services/form.service';
@Component({
  selector: 'app-conocimiento-usuario',
  templateUrl: './conocimiento-usuario.component.html',
  styleUrls: ['./conocimiento-usuario.component.scss'],
})
export class ConocimientoUsuarioComponent
  implements OnInit, AfterViewInit, OnChanges {
  @ViewChild('step1Form') formElement!: ElementRef;
  @Input() formId = ''
  showClienteInmoviliario = false;
  showArrendatarioPopup = false;
  showCatalogoPopup = false;
  ciiu: any;
  monedas: any;
  num = '';
  departamentos: any;
  ciudades: any;
  @Input() page1Valide = false;
  @Output() step = new EventEmitter<string>();
  ShowPopUp = false;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {
    singleSelection: true,
  };
  dropdownSettings2 = {
    singleSelection: false,
  };
  MessaggePopUp = {
    titulo: 'titulo',
    descripcion: 'texto explicativo',
    tipe: 'simple',
  };

  @Input() paises: { Nombre: string | any; Codigo: string }[] = [];
  @Input() form: any;
  selectHorizontePrevisto = [
    'Menos de un año',
    'Entre 1 y 3 años',
    'Mayor a 3 años',
  ];
  selectPropositoRelacion = [
    'Traslado de inmuebles para la administración',
    'Administrar cuentas de terceros',
    'Compra de unidad inmobiliaria',
    'Banca de Inversión',
    'Administrar recursos propios',
    'Diversificación de portafolio',
    'Dispersión de pagos',
    'Venta de TIDIS',
    'Venta de Acciones',
    'Negocios Fiduciarios',
    'Arrendatario PEI',
  ];
  selectMediosPagos = [
    'Transferencias Internacionales',
    'Transferencias Nacionales',
    'Cheque',
    'Efectivo',
  ];
  selectDocRepresentante = [
    'NIT',
    'Carnet Diplomático',
    'Cédula de Ciudadanía',
    'Cédula de Extranjería',
    'Pasaporte',
    'Permiso Especial de Permanencia',
    'NUIP',
    'Sin identificación del exterior',
    'Tarjeta de extranjería',
    'Tarjeta de identidad',
    'Tipo de documento extranjero',
  ];
  selectDocPN = [
    'NIT',
    'Carnet Diplomatico',
    'Cédula de Ciudadania',
    'Cédula de Extranjeria',
    'Pasaporte',
    'Permiso Especial de Permanencia',
    'NUIP',
    'Sin identificación del exterior',
    'Tarjeta de extranjería',
    'Tarjeta de identidad',
    'Tipo de documento extranjero',
  ];
  tiposDeSociedad = [
    'Comandita Simple',
    'Comandita por Acciones',
    'Economia Mixta',
    'Empresa Unipersonal',
    'Entidad sin Ánimo de Lucro',
    'Industrial y Comercial del Estado',
    'Responsabilidad Limitada',
    'Sociedad Anónima',
    'Sociedad por Acciones Simplificada',
    'Sociedad Colectiva',
    'Sociedad Extranjera',
    'Sociedades Cooperativas',
    'No aplica',
  ];
  selectOperacionesMoneda = [
    'Importaciones',
    'Exportaciones',
    'Transferencias',
    'Pagos de servicios',
    'Préstamos M/Ext',
    'Cambio de divisas',
    'Inversiones M/Ext',
    'Ingresos por donaciones',
    'Otros',
  ];
  selectTipoProducto = [
    '',
    'CDTs',
    'Otros Titulos del Gobierno',
    'Bonos de Deuda Pública',
    'Crédito',
    'Cuenta de ahorro',
    'Factoring',
    'Repos/Simultaneas',
    'Notas estructuradas',
    'Cartera Colectiva',
    'Fondos de pensiones',
    'Fondos de Valores',
    'Cuentas Corrientes',
    'Leasing',
    'Bonos Corporativos',
    'Acciones',
    'TES',
    'Otro Producto',
  ];
  selectCatalogoFiscal = [
    'Gran Contribuyente',
    'Sujeto de renta',
    'No sujeto de renta',
    'Régimen simple',
    'Régimen especial',
  ];
  // form =this.form;
  tributar_paises = [
    {
      name: '',
      tin: '',
    },
  ];
  constructor(private formService: FormService) { }
  code = document.getElementsByClassName('iti__selected-dial-code');
  submitInvalid = false;
  ngOnInit(): void {
    this.getPaises();
    this.loadExcelFromAssets();
    this.loadExcelFromMonedas();
    this.loadExcelFromDepartament();
    this.loadExcelFromCitys();
  }
  ngOnChanges(changes: SimpleChanges): void { }

  verifyProposito() { }
  onItemSelect(event?: any) {
    if (
      this.form.Informacion_cliente.datos_generales
        .proposito_relacion_comercial[0] == 'Compra de unidad inmobiliaria'
    ) {
      this.form.formato_anexo.activeInmobiliaria = true;
    } else {
      this.form.formato_anexo.activeInmobiliaria = false;
    }
    if (
      this.form.Informacion_cliente.datos_generales
        .proposito_relacion_comercial[0] == 'Arrendatario PEI'
    ) {
      this.showArrendatarioPopup = true;
      this.form.socios_accionistas = {
        prcentaje: 100,
        socios_directos: [],
        socios_indirectos: [{ socios: [], nivel: 1 }],
      };
    } else {
      this.form.formato_anexo.active = true;

      this.form.formato_anexo.PEI = false;
    }
  }
  onItemDeSelect(event?) {
    if (
      this.form.Informacion_cliente.datos_generales
        .proposito_relacion_comercial[0] == 'Compra de unidad inmobiliaria'
    ) {
      this.form.formato_anexo.activeInmobiliaria = false;
    }
    if (
      this.form.Informacion_cliente.datos_generales
        .proposito_relacion_comercial[0] == 'Arrendatario PEI'
    ) {
      this.form.formato_anexo.active = true;

      this.form.formato_anexo.PEI = false;
    }
  }
  ngAfterViewInit() {
    const telInput = document.getElementById('telInput');
    if (telInput) {
      intlTelInput(telInput, {
        initialCountry: 'CO',
        separateDialCode: true,
        utilsScript:
          'https://cdn.jsdelivr.net/npm/intl-tel-input@18.1.1/build/js/utils.js',
      });
    }
  }
  getPaises() {
    // this.paises = Object.keys(countries).map((code) => {
    //   return {
    //     name: (countries as { [code: string]: Country })[code].name,
    //     code: code,
    //   };
    // });
    const fileUrl = './assets/paises.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.paises = XLSX.utils.sheet_to_json(worksheet, {
            raw: true,
          });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  saveData(form: any) {
    // this.formService.saveForm(form);

    this.formService.saveFormDataFId(form, this.formId, true);
  }
  validateForm(step1Form: NgForm) {
    if (step1Form.valid) {
      this.submitInvalid = false;
      this.form.active_pages.page1 = true;
      // this.formService.saveForm(this.form);
      this.formService.saveFormDataFId(this.form, this.formId, true);

      this.step.emit('2');
    } else {
      this.submitInvalid = true;
      this.showActivePopUp(true);

      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'Hay campos sin diligenciar, verificar para continuar. *Los campos faltantes se muestran en rojo.';
      this.MessaggePopUp.tipe = 'alert';

      // @ts-ignore: Desactivar comprobaciones de TypeScript para esta sección
    }
  }
  quitarPais() {
    if (
      this.form.Informacion_cliente.datos_generales.paises_tributos.length > 1
    ) {
      this.form.Informacion_cliente.datos_generales.paises_tributos.pop();
    }
  }
  agregarPais() {
    this.form.Informacion_cliente.datos_generales.paises_tributos.push({
      pais: '',
      tin: '',
    });
  }
  activatePopUp(campo: string) {
    if (campo === 'catalogo') {
      if (
        this.form.Informacion_cliente.datos_tributarios.catalogo_fiscal ===
        'No sujeto de renta'
      ) {
        this.showCatalogoPopup = true;
        // this.MessaggePopUp.titulo = 'Recomendacion';
        // this.MessaggePopUp.tipe = 'simple';
        // this.MessaggePopUp.descripcion =
        //   'Por favor  entregar junto con los documentos de su vinculación la resolución o soporte que acredite su condición como no sujeto de renta';
      }
    } else if (campo === 'autorretencion') {
      if (
        this.form.Informacion_cliente.datos_tributarios.tipo_autorretencion !==
        'No aplica'
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Recomendación';

        this.MessaggePopUp.tipe = 'simple';
        this.MessaggePopUp.descripcion =
          'Por favor  entregar junto con los documentos de su vinculación la resolución o soporte que acredite su condición como autoretenedor';
      }
    }
  }
  showActivePopUp(status: boolean) {
    this.ShowPopUp = status;
  }
  calcularIngresosTotales() {
    let num1 =
      this.form.Informacion_cliente.informacion_financiera.ingresos_mensuales;
    let num2 =
      this.form.Informacion_cliente.informacion_financiera.otros_ingresos;
    if (num1 == '') {
      num1 = '0';
    }
    if (num2 == '') {
      num2 = '0';
    }

    let suma =
      parseInt(num1.replace(/[^\d]/g, '')) +
      parseInt(num2.replace(/[^\d]/g, ''));

    this.form.Informacion_cliente.informacion_financiera.total_ingresos_mensuales =
      suma.toLocaleString('de-DE');
  }
  addFuncionario() {
    this.form.Informacion_cliente.funcionarios_de_la_empresa.otro.push({
      nombre: '',
      tipo_documento: '',
      documento: '',
      email: '',
    });
  }
  deleteFuncionario(index: any) {
    this.form.Informacion_cliente.funcionarios_de_la_empresa.otro.splice(
      index,
      1,
    );
  }
  loadExcelFromAssets() {
    const fileUrl = './assets/ciiu.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.ciiu = XLSX.utils.sheet_to_json(worksheet, { raw: true });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  loadExcelFromCitys() {
    const fileUrl = './assets/ciudades.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.ciudades = XLSX.utils.sheet_to_json(worksheet, { raw: true });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  loadExcelFromPais() {
    const fileUrl = './assets/ciudades.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.ciudades = XLSX.utils.sheet_to_json(worksheet, { raw: true });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  loadExcelFromDepartament() {
    const fileUrl = './assets/departamentos.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.departamentos = XLSX.utils.sheet_to_json(worksheet, {
            raw: true,
          });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  loadExcelFromMonedas() {
    const fileUrl = './assets/monedas.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.monedas = XLSX.utils.sheet_to_json(worksheet, { raw: true });
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }

  autoselectCIIU() {
    if (this.form.Informacion_cliente.datos_generales.codigo_CIIU !== '') {
      const campoCIIU = this.ciiu.filter(
        (codigo: any) =>
          codigo.codigo ===
          this.form.Informacion_cliente.datos_generales.codigo_CIIU,
      );
      if (campoCIIU.length > 0) {
        this.form.Informacion_cliente.datos_generales.actividada_economica =
          campoCIIU[0].Nombre;
      } else {
        this.form.Informacion_cliente.datos_generales.actividada_economica = '';
      }
    } else {
      this.form.Informacion_cliente.datos_generales.actividada_economica = '';
    }

    // const campoCIIU2 = this.ciiu.filter(
    //   (codigo: any) =>
    //     codigo.codigo ===
    //     this.form.Informacion_cliente.datos_generales.codigo_CIIU
    // );
    // this.form.Informacion_cliente.datos_generales.actividada_economica =
    //   campoCIIU2[0].Nombre;
  }

  activatePopUpCliente() {
    // let indice =
    //   this.form.Informacion_cliente.datos_generales.proposito_relacion_comercial.indexOf(
    //     'Compra de unidad Inmobiliaria'
    //   );
    // if (indice !== -1) {
    //   this.showClienteInmoviliario = true;
    // } else {
    // }
  }
  validateSuperfinanciera() {
    if (this.form.activate_anexo == 'SI') {
      this.step.emit('4');
    }
  }

  calculateDV(numNit: any) {
    var vpri, x, y, z;
    let stringNit = numNit.toString();
    // Se limpia el Nit
    // numNit = numNit.replace(/\s/g, ''); // Espacios
    // numNit = numNit.replace(/,/g, ''); // Comas
    // numNit = numNit.replace(/\./g, ''); // Puntos
    // numNit = numNit.replace(/-/g, ''); // Guiones

    // Se valida el nit
    if (isNaN(numNit)) {
      alert("El nit/cédula '" + numNit + "' no es válido(a).");
      return '';
    }

    // Procedimiento
    vpri = new Array(16);
    z = stringNit.length;

    vpri[1] = 3;
    vpri[2] = 7;
    vpri[3] = 13;
    vpri[4] = 17;
    vpri[5] = 19;
    vpri[6] = 23;
    vpri[7] = 29;
    vpri[8] = 37;
    vpri[9] = 41;
    vpri[10] = 43;
    vpri[11] = 47;
    vpri[12] = 53;
    vpri[13] = 59;
    vpri[14] = 67;
    vpri[15] = 71;

    x = 0;
    y = 0;
    for (var i = 0; i < z; i++) {
      y = stringNit.substr(i, 1);

      x += y * vpri[z - i];
    }

    y = x % 11;

    return y > 1 ? 11 - y : y;
  }

  checkDv1(inputNum: number) {
    if (
      this.form.Informacion_cliente.datos_generales.tipo_documento == 'NIT' &&
      inputNum == 1
    ) {
      this.form.Informacion_cliente.datos_generales.dv = this.calculateDV(
        this.form.Informacion_cliente.datos_generales.documento,
      );
    } else if (
      this.form.Informacion_cliente.datos_generales.controlante
        .tipo_documento == 'NIT' &&
      inputNum == 2
    ) {
      this.form.Informacion_cliente.datos_generales.controlante.dv =
        this.calculateDV(
          this.form.Informacion_cliente.datos_generales.controlante.documento,
        );
    } else if (
      this.form.Informacion_cliente.representante_legal.tipo_documento ==
      'NIT' &&
      inputNum == 3
    ) {
      this.form.Informacion_cliente.representante_legal.dv = this.calculateDV(
        this.form.Informacion_cliente.representante_legal.documento,
      );
    }
  }
  deleteDataFinancieros(input: any) {
    if (
      this.form.Informacion_cliente.operaciones_internacionales
        .productos_en_moneda_extranjera == 'NO' &&
      input == 1
    ) {
      this.form.Informacion_cliente.operaciones_internacionales.tipo_producto =
        '';
      this.form.Informacion_cliente.operaciones_internacionales.cual_producto =
        '';
      this.form.Informacion_cliente.operaciones_internacionales.identificacion_del_producto =
        '';
      this.form.Informacion_cliente.operaciones_internacionales.entidad_producto =
        '';
      ('');
      this.form.Informacion_cliente.operaciones_internacionales.moneda_producto =
        '';
      ('');
      this.form.Informacion_cliente.operaciones_internacionales.ciudad = '';
      this.form.Informacion_cliente.operaciones_internacionales.monto_producto =
        '';
      this.form.Informacion_cliente.operaciones_internacionales.pais = '';
    } else if (
      this.form.Informacion_cliente.operaciones_internacionales
        .realiza_operaciones_moneda_extranjera == 'NO' &&
      input == 2
    ) {
      this.form.Informacion_cliente.operaciones_internacionales.tipo_operacion_realizada =
        [];
      this.form.Informacion_cliente.operaciones_internacionales.otros = '';
    }
  }
  closedModalPei(status: boolean) {
    this.showArrendatarioPopup = status;
  }
}
