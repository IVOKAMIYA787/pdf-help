export const rutas = {
  home: 'home',
  code: 'home/verifyCode',
  form: {
    home: 'form',
  },
};
