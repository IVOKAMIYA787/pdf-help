export const environment = {
  production: true,

  CODE_ACCESS: 'Corfi_form_434%$',
  URL_DOMAIN: 'https://pruebas.vozavoz.com.co',
  SECRET: 'kEY_FTCORIF_2023',
  EMAIL: {
    EMAILADMIN: '',
    DOMAIN_HOST: 'smtp-relay.sendinblue.com',
    EMAIL_SUPPORT: '',

    PORT_SMTP: '587',
    PASS_EMAIL: '5PLIfR6EC8qDbpUW',
  },
};
