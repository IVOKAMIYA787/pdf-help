import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TdSocioSuperiorComponent } from './td-socio-superior.component';

describe('TdSocioSuperiorComponent', () => {
  let component: TdSocioSuperiorComponent;
  let fixture: ComponentFixture<TdSocioSuperiorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TdSocioSuperiorComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TdSocioSuperiorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
