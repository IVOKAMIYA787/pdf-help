import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { rutas } from '../rutas/rutas';

@Injectable({
  providedIn: 'root',
})
export class RedirectGuard  {
  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}
  canActivate(): boolean {
    const code = this.authService.getCode();
    console.log(code);
    if (code) {
      this.router.navigate([rutas.home]);
      return false;
    }
    return true;
  }
}
