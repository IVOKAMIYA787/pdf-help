import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import jsPDF from 'jspdf';
import { FormService } from 'src/app/services/form.service';
import { formData } from 'src/app/utils/form.utils';
@Component({
  selector: 'app-pdf-anexo',
  templateUrl: './pdf-anexo.component.html',
  styleUrls: ['./pdf-anexo.component.scss'],
})
export class PdfAnexoComponent implements OnInit {
  @Input() form = formData;
  formCode = '';
  @ViewChild('pagina1') pagina1!: ElementRef;
  totalNumPages = 5;
  fechaActual: Date = new Date();
  loader = false;
  fechaDi = '';
  constructor(private formService: FormService,
    private _route: ActivatedRoute,) {
    this.formCode = this._route.snapshot.paramMap.get('code');
  }
  ngOnInit(): void {
    let dia: number = this.fechaActual.getDate();
    let mes: number = this.fechaActual.getMonth() + 1; // Meses comienzan desde 0
    let anio: number = this.fechaActual.getFullYear() % 100;
    this.fechaDi = `${dia < 10 ? '0' : ''}${dia}-${mes < 10 ? '0' : ''}${mes}-${anio < 10 ? '0' : ''
      }${anio}`;
  }
  async getFormData() {
    const form = await this.formService.getForms();
    if (form) {
      let index = form.forms.findIndex((f: any) => f.id === this.formCode);
      if (form.forms[index]) {

        // this.status = 'valid';
        this.form = form.forms[index]

      }

    }
  }
  // async generarPDF() {
  //   this.loader = true;
  //   // this.formService.saveForm(this.form);
  //   this.formService.saveFormDataFId(this.form, this.formCode, true);

  //   // this.getFormData();
  //   const pdf = new jsPDF('p', 'px', [816, 1344]);
  //   const options = {
  //     margin: {
  //       top: 10,
  //       bottom: 10,
  //     },
  //   };
  //   const content = this.pagina1.nativeElement;
  //   const name = this.form.Informacion_cliente.datos_generales.razon_social;
  //   // pdf.html(content, {
  //   //   callback: function () {
  //   //     pdf.save('Formulario_anexo_' + name);
  //   //   },
  //   //   autoPaging: 'text',

  //   //   margin: [0, 10, 0, 0],
  //   //   html2canvas: {
  //   //     scale: 1,
  //   //   },
  //   // });
  //   const addPageNumbers = (pdf) => {
  //     const pageCount = pdf.internal.getNumberOfPages();
  //     for (let i = 1; i <= pageCount - 1; i++) {
  //       pdf.setPage(i);
  //       pdf.setFontSize(10);
  //       pdf.text(`Pagina ${i} / ${pageCount - 1}`, pdf.internal.pageSize.getWidth() - 10, pdf.internal.pageSize.getHeight() - 10, {
  //         align: 'right'
  //       });
  //     }
  //   };
  //   await new Promise((resolve, reject) => {
  //     pdf.html(content, {
  //       callback: function () {
  //         addPageNumbers(pdf);
  //         pdf.save('Formulario_anexo_' + name);
  //         resolve(1);
  //       },
  //       autoPaging: 'text',
  //       margin: [0, 0, 0, 0],

  //       html2canvas: {
  //         scale: 1,
  //       },
  //     });
  //   });
  //   // ...
  //   this.loader = false;
  // }
  async generarPDF() {
    this.loader = true;

    const pdf = new jsPDF('p', 'px', [816, 1344]);

    const addPageNumbers = (pdf) => {
      const pageCount = pdf.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount - 1; i++) {
        pdf.setPage(i);
        pdf.setFontSize(10);
        pdf.text(`Pagina ${i} / ${pageCount - 1}`, pdf.internal.pageSize.getWidth() - 10, pdf.internal.pageSize.getHeight() - 10, {
          align: 'right'
        });
      }
    };

    const preloadImages = () => {
      return new Promise<void>((resolve) => {
        const images = Array.from(document.images);
        let loaded = 0;
        images.forEach((image) => {
          if (image.complete) {
            loaded++;
            if (loaded === images.length) resolve();
          } else {
            image.onload = () => {
              loaded++;
              if (loaded === images.length) resolve();
            };
          }
        });
      });
    };

    const content = this.pagina1.nativeElement;
    await preloadImages(); // Pre-cargar las imágenes

    await new Promise<void>((resolve, reject) => {
      pdf.html(content, {
        callback: function () {
          try {
            addPageNumbers(pdf);
            pdf.save('Formulario_vinculacion_' + 'nombre_del_cliente');
            resolve();
          } catch (error) {
            reject(error);
          }
        },
        margin: [0, 10, 0, 0],
        html2canvas: {
          scale: 1,
        },
      });
    }).catch((error) => {
      console.error("Error al generar el PDF", error);
    });

    this.loader = false;
  }
}
