import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import * as emailjs from '@emailjs/browser';
import { AuthService } from './auth.service';
import { rutas } from '../rutas/rutas';
@Injectable({
  providedIn: 'root',
})
export class EmailsService {
  smtpConfig = {
    username: environment.EMAIL.EMAIL_SUPPORT,
    password: environment.EMAIL.PASS_EMAIL,
    host: environment.EMAIL.DOMAIN_HOST, // Ejemplo para Gmail, ajusta el servidor SMTP según tu proveedor
    port: environment.EMAIL.PORT_SMTP, // Puerto seguro SMTP
  };
  data = {
    service_id: 'service_4r4dfop',
    template_id: 'template_8x5kzd9',
    user_id: 'YOUR_PUBLIC_KEY',
    public_key: 'cXF8bkzvdz_ny_znE',
  };
  constructor() {}
  ngOnInit(): void {}
  sendEmail(user_email: any, code: string) {
    var templateParams = {
      user_email: user_email,
      link: environment.URL_DOMAIN + '/' + rutas.form.home + '/' + code,
    };
    return emailjs.send(
      this.data.service_id,
      this.data.template_id,
      templateParams,
      this.data.public_key,
    );
    // .then(
    //   function (response) {
    //     console.log('SUCCESS!', response.status, response.text);
    //   },
    //   function (error) {
    //     console.log('FAILED...', error);
    //   }
    // );
  }
}
