import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { rutas } from '../rutas/rutas';

@Injectable({
  providedIn: 'root',
})
export class CheckCodeGuard  {
  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}
  canActivate(): boolean {
    const code = this.authService.getCode();
    if (!code) {
      this.router.navigate([rutas.code]);
      return false;
    }
    return true;
  }
}
