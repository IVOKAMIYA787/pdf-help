import { Component } from '@angular/core';

@Component({
  selector: 'app-tool3',
  templateUrl: './tool3.component.html',
  styleUrls: ['./tool3.component.scss'],
})
export class Tool3Component {
  isVisible: boolean = false;

  showTooltip() {
    this.isVisible = true;
  }

  hideTooltip() {
    this.isVisible = false;
  }
}
