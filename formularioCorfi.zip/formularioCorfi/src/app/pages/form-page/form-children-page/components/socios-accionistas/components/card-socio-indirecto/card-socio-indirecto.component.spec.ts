import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardSocioIndirectoComponent } from './card-socio-indirecto.component';

describe('CardSocioIndirectoComponent', () => {
  let component: CardSocioIndirectoComponent;
  let fixture: ComponentFixture<CardSocioIndirectoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CardSocioIndirectoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CardSocioIndirectoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
