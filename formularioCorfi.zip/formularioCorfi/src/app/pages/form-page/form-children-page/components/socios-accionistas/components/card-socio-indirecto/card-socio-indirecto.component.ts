import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

import * as XLSX from 'xlsx';
import { countries, Country } from 'countries-list';
import { ExcelsService } from '../../../../../../../services/excels.service';
import {
  criterio_determinacion_no,
  criterio_determinacion_si,
} from 'src/app/utils/criterios';
import { formData } from 'src/app/utils/form.utils';
import { NgForm } from '@angular/forms';
import { FormService } from 'src/app/services/form.service';
@Component({
  selector: 'app-card-socio-indirecto',
  templateUrl: './card-socio-indirecto.component.html',
  styleUrls: ['./card-socio-indirecto.component.scss'],
})
export class CardSocioIndirectoComponent implements OnInit {
  @Input() nivel = '';
  @Input() index = 0;
  updateActive = false;

  @Output() step = new EventEmitter<string>();
  @Input() formCode: any;
  formCopy: any;
  activePDF = false
  @Output() changeNavigator = new EventEmitter<number>();
  existPersonaJuridica: any;
  existDesgloseActive: any;
  resPorcent = 0;
  resPorcentBeneficiario = 0;
  updateIndex: any;
  nivelValid = parseInt(this.nivel);
  MessaggePopUp = {
    titulo: 'titulo',
    descripcion: 'texto explicativo',
    tipe: 'simple',
  };
  ShowPopUp = false;

  ShowPopUp2 = false;
  constructor(
    private excelService: ExcelsService,
    private formService: FormService,
  ) { }
  selectSocios: any = [];
  selectSocios2: any = [];
  tipoCriterio: string;
  criterio_determinacion_no = criterio_determinacion_no;
  criterio_determinacion_si = criterio_determinacion_si;
  updateActiveCriterio = false;
  @Input() form: any;
  @Input() stepNavigator: any;

  parentesco = [
    '1. Sociedad conyugal de hecho o de derecho',
    '2. Primer grado de consanguinidad: Padre, madre, hijos',
    '3. Segundo grado de consanguinidad: Abuelos, nietos, hermanos',
    '4. Primer grado afinidad: Suegro, yerno, nuera',
    '5. Segundo grado de adinidad: Abuelos del cónyugue, nietos del cónyugue, cuñados',
    '6. Primero civil: Padres adoptadores, hijos adoptivos',
    '7. Asociado cercano de PEP (asesores, consultores personales y las personas que se benefician significativamente) ',
  ];
  tributar_paises = [
    {
      name: '',
      tin: '',
    },
  ];
  submitInvalid = false;
  minParticipacionC = 0;
  minParticipacionB = 0;
  maxParticipacionC = 0;
  maxParticipacionB = 0;
  paises: { Nombre: string | any; Codigo: string }[] = [];

  departamentos: { Nombre: string | any; Codigo: string }[] = [];
  add_socio: any = {
    id: '',
    socio_superior: '',
    tipo: 'Socio indirecto',
    tipo_persona: '',
    nivel: this.index + 1,
    razon_social: '',
    participacion_capital: 0,
    beneficios_rendimientos_utilidades: 0,
    datos: {},
  };
  add_socio_copy = {
    id: '',
    socio_superior: '',
    tipo: 'Socio indirecto',
    tipo_persona: '',
    nivel: this.index + 1,
    razon_social: '',
    participacion_capital: 0,
    beneficios_rendimientos_utilidades: 0,
    datos: {},
  };
  datos_p_natural = {
    razon_social: '',
    razon_social_socio: '',
    primer_apellido: '',
    segundo_apellido: '',
    primer_nombre: '',
    otro_nombre: '',
    tipo_identificacion: '',
    numero_identificacion: '',
    dv: '',
    pais_expedicion_documento: '',
    fecha_nacimiento: '',
    pais_nacimiento: '',
    pais_nacionalidad: '',
    pais_residencia: '',
    departamento_notificacion: '',
    municipio_notificacion: '',
    direccion_notificacion: '',
    codigo_postal_direccion: '',
    correo_electronico: '',
    criterio_determinacion_bf: '',
    porcentaje_participacion: '',
    porcentaje_beneficios: '',
    obligado_a_tributar: '',
    pais: '',
    tin: '',
    persona_expuesta_politicamente: '',
    entidad: '',
    inscrito: '',
    cargo_ocupacion: '',
    fecha_vinculacion: '',
    fecha_desvinculacion: '',
    vinculacon_persona_expuesta_politicamente: '',
    parentesco: '',
    nombre_apellido_familiar: '',
    tipo_identificacion_familiar: '',
    numero_identificacion_familia: '',
    origen_riqueza: '',
  };

  datos_p_juridica = {
    razon_social_socio: '',
    razon_social: '',
    tipo_identificacion: '',
    numero_identificacion: '',
    dv: '',
    nacionalidad: '',
    direccion: '',
    codigo_postal: '',
    obligado_a_tributar: '',
    pais: '',
    tin: '',
    inscrito: '',

    criterio_determinacion_bf: '',
    porcentaje_participacion: '',
    porcentaje_beneficios: '',
  };

  id_persona_natural = [
    'NIT',
    'Sin identificación del extranjero',
    'Tipo de documento extranjero',
    'NUIP',
    'Tarjeta de identidad',
    'Cédula de ciudadanía',
    'Tarjeta de extranjería',
    'Cédula de extranjeria',
    'Pasaporte',
    'Permiso especial de permanecia',
  ];
  id_persona_juridica = [
    'NIT',
    'Sociedad Extranjera sin NIT en Colombia',
    'Tipo de documento extranjero',
  ];
  id_persona_normal = [
    'NUIP',
    'Tarjeta de identidad',
    'Cédula de ciudadanía',
    'Tarjeta de extranjería',
    'Cédula de extranjería',
    'Pasaporte',
    'Tipo documento extranjero',
    'Permiso Especial de Permanencia',
  ];

  selectOrigenBienes = [
    '',
    'AHORROS LABORALES',
    'ACTIVIDAD ECONOMICA',
    'APORTES SOCIOS',
    'COMPRA VENTA DE BIENES',
    'DIVIDENDOS Y PARTICIPACIONES',
    'DONACION DE PARTICULARES',
    'EJERCICIO ACT PROFESIONAL',
    'EXCEDENTES DE CAPITAL',
    'GANANCIA OCASIONAL ',
    'INGRESOS POR  DIVIDENDOS',
    'INGRESOS POR SALARIO',
    'LIQUIDACIÓN DE SOCIEDAD',
    'LIQUIDACIÓN LABORAL',
    'MESADA PADRES O HIJOS',
    'NEGOCIO PROPIO',
    'OBSEQUIO DE FAMILIARES',
    'OBJETO SOCIAL DEL NEGOCIO',
    'PAGO DE SEGUROS O INDEMNIZACION',
    'PARTICIPACIÓN EN SOCIEDADES',
    'PENSION',
    'PREMIO  DE LOTERIA',
    'AHORROS FAMILIARES',
    'PRESTAMOS DE ENTIDADES FINANCIERAS',
    'RENDIMIENTOS FINANCIEROS',
    'RENTA',
    'RENTAS DE CAPITAL',
    'RETIRO DE CESANTIAS',
    'RIFAS',
    'TRANSFERENCIA DEL EXTERIOR',
    'VENTAS DE ACCIONES',
    'VENTAS DE ACTIVOS',
    'VENTA DE APARTAMENTO',
    'VENTA DE BODEGA',
    'VENTA DE  CASA',
    'ARRENDAMIENTOS',
    'VENTA DE EDIFICIO',
    'VENTA DE FINCA',
    'VENTA DE LOTE',
    'VENTA DE OFICINA',
    'VENTA DE PRODUCTOS AGRICOLAS',
    'VENTA DE TITULOS',
    'VENTA DE VEHICULO',
    'VENTA OTROS ACTIVOS',
    'VENTA DE VALORES',
    'POLIZAS',
    'SEGUROS',
    'COMERCIALIZACION SEMOVIENTES',
    'DONACIONES DE  EMPRESAS',
    'DONACIONES DE PARTICULARES',
    'EXCEDENTES DE CAPITAL',
    'HERENCIAS',
    'HONORARIOS POR ASESORIAS',
  ];
  ngOnInit(): void {
    this.getPaises();
    this.getSocios();
    this.getSocios2();
    this.validateSociosJuridicos();
    this.validateDesgloseSocios();
  }

  changeStep(step: string) {
    this.step.emit(step);
    this.form.active_pages.page3 = true;
  }
  getSocios() {
    if (this.nivel == '1') {
      this.form.socios_accionistas.socios_directos.forEach((socio: any) => {
        if (
          socio.tipo_persona == 'juridica' ||
          socio.tipo_persona == 'sin juridica'
        ) {
          if (
            socio.participacion_capital >= 5 ||
            socio.beneficios_rendimientos_utilidades >= 5
          ) {
            this.selectSocios.push(socio);
          }
        }
      });
    } else {
      this.form.socios_accionistas.socios_indirectos[
        this.index - 1
      ].socios.forEach((socio: any) => {
        if (
          socio.tipo_persona == 'juridica' ||
          socio.tipo_persona == 'sin juridica'
        ) {
          if (
            socio.participacion_capital >= 5 ||
            socio.beneficios_rendimientos_utilidades >= 5
          ) {
            this.selectSocios.push(socio);
          }
        }
      });
    }
  }
  getSocios2() {
    this.form.socios_accionistas.socios_indirectos[this.index].socios.forEach(
      (socio: any) => {
        if (
          socio.tipo_persona == 'juridica' ||
          socio.tipo_persona == 'sin juridica'
        ) {
          if (
            socio.participacion_capital >= 5 ||
            socio.beneficios_rendimientos_utilidades >= 5
          ) {
            this.selectSocios2.push(socio);
          }
        }
      },
    );
  }

  // async getPaises() {
  //   this.paises = await this.excelService
  //     .getCountrys()
  //     .then((response) => {
  //       console.log(response);
  //     })
  //     .catch((err: any) => {
  //       console.log(err);
  //     });
  // }
  getPaises() {
    // this.paises = Object.keys(countries).map((code) => {
    //   return {
    //     name: (countries as { [code: string]: Country })[code].name,
    //     code: code,
    //   };
    // });
    const fileUrl = './assets/paises.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.paises = XLSX.utils.sheet_to_json(worksheet, {
            raw: true,
          });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
  addNivel() {
    if (
      this.form.socios_accionistas.socios_indirectos[this.index].socios.length >
      0 &&
      !this.existDesgloseActive
    ) {
      this.form.socios_accionistas.socios_indirectos.push({
        socios: [],
        nivel: parseInt(this.nivel) + 1,
      });
      this.changeNavigator.emit(this.index + 1);
      if (this.form.socios_accionistas.socios_indirectos.length == 2) {
      }
    } else {
      this.submitInvalid = true;
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'Debes desglosar primero este nivel antes de añadir uno nuevo';
      this.MessaggePopUp.tipe = 'alert';
    }
  }
  deleteNivel() {
    this.form.socios_accionistas.socios_indirectos.pop();
    this.changeNavigator.emit(this.index - 1);
  }
  validateForm(step1Form: NgForm) {
    if (this.selectSocios.length > 0 && this.add_socio.socio_superior != '') {
      if (step1Form.valid) {
        let sumPorcent = 0;
        let sumPorcentBeneficiario = 0;

        this.form.socios_accionistas.socios_indirectos[
          this.index
        ].socios.forEach((element: any) => {
          if (element.socio_superior == this.add_socio.socio_superior) {
            sumPorcent = sumPorcent + element.participacion_capital;
          }
        });
        this.form.socios_accionistas.socios_indirectos[
          this.index
        ].socios.forEach((element: any) => {
          if (element.socio_superior == this.add_socio.socio_superior) {
            sumPorcentBeneficiario =
              sumPorcentBeneficiario +
              element.beneficios_rendimientos_utilidades;
          }
        });
        this.submitInvalid = false;
        if (this.add_socio.tipo_persona == 'natural') {
          if (
            sumPorcent +
            parseFloat(this.datos_p_natural.porcentaje_participacion) -
            this.resPorcent <=
            100
          ) {
            if (
              sumPorcentBeneficiario +
              parseFloat(this.datos_p_natural.porcentaje_beneficios) -
              this.resPorcentBeneficiario <=
              100
            ) {
              this.add_socio.datos = this.datos_p_natural;
              this.add_socio.razon_social =
                this.datos_p_natural.primer_nombre +
                ' ' +
                this.datos_p_natural.primer_apellido;
              this.add_socio.participacion_capital = parseFloat(
                this.datos_p_natural.porcentaje_participacion,
              );
              this.add_socio.beneficios_rendimientos_utilidades = parseFloat(
                this.datos_p_natural.porcentaje_beneficios,
              );
              this.add_socio.id =
                this.form.socios_accionistas.socios_directos.length + 1;
              if (this.updateActive) {
                this.updateData(sumPorcent);
              } else {
                this.saveData(sumPorcent);
              }
              this.changeNavigator.emit(this.index);
            } else {
              this.submitInvalid = true;
              this.showActivePopUp(true);
              this.MessaggePopUp.titulo = 'Alerta';
              this.MessaggePopUp.descripcion =
                'Estas excediendo el 100% de porcentaje de beneficio en rendimientos y utilidades, verifica los datos que estas proporcionando';
              this.MessaggePopUp.tipe = 'alert';
            }
          } else {
            this.submitInvalid = true;
            this.showActivePopUp(true);
            this.MessaggePopUp.titulo = 'Alerta';
            this.MessaggePopUp.descripcion =
              'Estas excediendo el 100% de participacion en el capital, verifica los datos que estas proporcionando';
            this.MessaggePopUp.tipe = 'alert';
          }
        } else {
          if (
            sumPorcent +
            parseFloat(this.datos_p_juridica.porcentaje_participacion) -
            this.resPorcent <=
            100
          ) {
            if (
              sumPorcentBeneficiario +
              parseFloat(this.datos_p_juridica.porcentaje_beneficios) -
              this.resPorcentBeneficiario <=
              100
            ) {
              this.add_socio.datos = this.datos_p_juridica;
              this.add_socio.razon_social = this.datos_p_juridica.razon_social;
              this.add_socio.participacion_capital = parseFloat(
                this.datos_p_juridica.porcentaje_participacion,
              );
              this.add_socio.beneficios_rendimientos_utilidades = parseFloat(
                this.datos_p_juridica.porcentaje_beneficios,
              );
              if (this.updateActive) {
                this.updateData(sumPorcent);
              } else {
                let arrayDeNumeros =
                  this.form.socios_accionistas.socios_indirectos[
                    this.index
                  ].socios.map(function (objeto) {
                    return objeto.id;
                  });
                var numeroMaximo = Math.max(...arrayDeNumeros);
                if (numeroMaximo > 0) {
                  this.add_socio.id = numeroMaximo + 1;
                  // this.add_socio.id =
                  //   this.form.socios_accionistas.socios_directos.length + 1;
                } else {
                  this.add_socio.id = 1;
                }
                this.saveData(sumPorcent);
              }
              this.getSocios2();
              this.validateSociosJuridicos();
              this.changeNavigator.emit(this.index);
            } else {
              this.submitInvalid = true;
              this.showActivePopUp(true);
              this.MessaggePopUp.titulo = 'Alerta';
              this.MessaggePopUp.descripcion =
                'Estas excediendo el 100% de porcentaje de beneficio en rendimientos y utilidades, verifica los datos que estas proporcionando';
              this.MessaggePopUp.tipe = 'alert';
            }
          } else {
            this.submitInvalid = true;
            this.showActivePopUp(true);
            this.MessaggePopUp.titulo = 'Alerta';
            this.MessaggePopUp.descripcion =
              'Estas excediendo el 100% de participacion en el capital, verifica los datos que estas proporcionando';
            this.MessaggePopUp.tipe = 'alert';
          }
        }
      } else {
        this.submitInvalid = true;
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Tienes campos sin diligenciar, verifica antes de continuar';
        this.MessaggePopUp.tipe = 'alert';
      }
    } else {
      this.submitInvalid = true;
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'No has seleccionado P jurídica con relacion directa o indirecta';
      this.MessaggePopUp.tipe = 'alert';
    }
  }
  saveData(sum: any) {
    this.form.socios_accionistas.socios_indirectos[this.index].socios.push(
      this.add_socio,
    );
    this.resetData();

    let exist = this.validateSociosJuridicos();
    this.validateDesgloseSocios();
    if (!exist && !this.existDesgloseActive) {
      this.form.active_pages.page3 = true;
    } else {
      this.form.active_pages.page3 = false;
    }
    // this.formService.saveForm(this.form);


    this.formService.saveFormDataFId(this.form, this.formCode, true);
  }
  updateData(sum: any) {
    this.form.socios_accionistas.socios_indirectos[this.index].socios[
      this.updateIndex
    ] = this.add_socio;

    this.resetData();
    this.validateDesgloseSocios();
    this.validateSociosJuridicos();
    if (!this.existPersonaJuridica && !this.existDesgloseActive) {
      this.form.active_pages.page3 = true;
    } else {
      this.form.active_pages.page3 = false;
    }
    // this.formService.saveForm(this.form);

    this.formService.saveFormDataFId(this.form, this.formCode, true);
  }
  showActivePopUp(status: boolean) {
    this.ShowPopUp = status;
  }
  showActivePopUp2(status: boolean) {
    this.ShowPopUp2 = status;
  }
  resetData() {
    if (this.updateActive) {
      this.form = this.formCopy;
    }
    this.formCopy = '';
    this.submitInvalid = false;
    this.add_socio = {
      id: '',
      tipo: 'Socio indirecto',
      tipo_persona: '',
      nivel: 0,
      razon_social: '',
      participacion_capital: 0,
      beneficios_rendimientos_utilidades: 0,
      datos: {},
    };

    this.resPorcent = 0;

    this.datos_p_natural = {
      razon_social: '',
      razon_social_socio: '',
      primer_apellido: '',
      segundo_apellido: '',
      primer_nombre: '',
      otro_nombre: '',
      tipo_identificacion: '',
      numero_identificacion: '',
      dv: '',
      pais_expedicion_documento: '',
      fecha_nacimiento: '',
      pais_nacimiento: '',
      pais_nacionalidad: '',
      pais_residencia: '',
      departamento_notificacion: '',
      municipio_notificacion: '',
      direccion_notificacion: '',
      codigo_postal_direccion: '',
      correo_electronico: '',
      criterio_determinacion_bf: '',
      porcentaje_participacion: '',
      porcentaje_beneficios: '',
      obligado_a_tributar: '',
      pais: '',
      tin: '',
      persona_expuesta_politicamente: '',
      entidad: '',
      inscrito: '',
      cargo_ocupacion: '',
      fecha_vinculacion: '',
      fecha_desvinculacion: '',
      vinculacon_persona_expuesta_politicamente: '',
      parentesco: '',
      nombre_apellido_familiar: '',
      tipo_identificacion_familiar: '',
      numero_identificacion_familia: '',
      origen_riqueza: '',
    };
    this.datos_p_juridica = {
      razon_social_socio: '',
      razon_social: '',
      tipo_identificacion: '',
      numero_identificacion: '',
      dv: '',
      nacionalidad: '',
      direccion: '',
      codigo_postal: '',
      obligado_a_tributar: '',
      pais: '',
      tin: '',
      inscrito: '',

      criterio_determinacion_bf: '',
      porcentaje_participacion: '',
      porcentaje_beneficios: '',
    };
    this.updateActive = false;
    this.updateIndex = null;

    this.resPorcent = 0;
    this.resPorcentBeneficiario = 0;
  }

  deleteSocio(i: any, nombre: string) {
    let haveSocios = false;
    for (
      let i = 0;
      i < this.form.socios_accionistas.socios_indirectos.length;
      i++
    ) {
      for (
        let x = 0;
        x < this.form.socios_accionistas.socios_indirectos[i].socios.length;
        x++
      ) {
        if (
          this.form.socios_accionistas.socios_indirectos[i].socios[x]
            .socio_superior == nombre
        ) {
          haveSocios = true;
          break;
        }
      }
      if (haveSocios) {
        break;
      }
    }
    if (haveSocios) {
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'No se puede eliminar, tiene socios indirectos vinculados  ';
      this.MessaggePopUp.tipe = 'alert';
    } else {
      this.form.socios_accionistas.socios_indirectos[this.index].socios.splice(
        i,
        1,
      );
      this.getSocios2();
      let exist = this.validateSociosJuridicos();
      this.validateDesgloseSocios();
      if (!exist && !this.existDesgloseActive) {
        this.form.active_pages.page3 = true;
      } else {
        this.form.active_pages.page3 = false;
      }
      // this.formService.saveForm(this.form);

      this.formService.saveFormDataFId(this.form, this.formCode, true);
      this.resetData();
    }
  }
  activateEdit(i: any) {
    this.resetData();
    this.updateActive = true;
    this.updateIndex = i;

    this.resPorcent =
      this.form.socios_accionistas.socios_indirectos[this.index].socios[
        i
      ].participacion_capital;
    this.resPorcentBeneficiario =
      this.form.socios_accionistas.socios_indirectos[this.index].socios[
        i
      ].beneficios_rendimientos_utilidades;
    this.add_socio =
      this.form.socios_accionistas.socios_indirectos[this.index].socios[i];

    this.changeCriterios();
    if (this.add_socio.tipo_persona == 'natural') {
      this.datos_p_natural = this.add_socio.datos;
      this.updateActiveCriterio = true;
      if (this.tipoCriterio == 'juridica') {
        this.validateCriterio(
          'NO',
          this.add_socio.datos.criterio_determinacion_bf,
        );
      } else {
        this.validateCriterio(
          'SI',
          this.add_socio.datos.criterio_determinacion_bf,
        );
      }
      // this.datos_p_natural.porcentaje_participacion =
      //   this.add_socio.datos.porcentaje_participacion;
      // this.datos_p_natural.porcentaje_beneficios =
      //   this.add_socio.datos.porcentaje_beneficios;
    } else {
      this.datos_p_juridica = this.add_socio.datos;
      this.updateActiveCriterio = true;
      if (this.tipoCriterio == 'juridica') {
        this.validateCriterioJuridico(
          'NO',
          this.add_socio.datos.criterio_determinacion_bf,
        );
      } else {
        this.validateCriterioJuridico(
          'SI',
          this.add_socio.datos.criterio_determinacion_bf,
        );
      }
    }

    this.formCopy = this.form;
  }
  buscarSocio(id: any) {
    let socio = this.selectSocios.find((socio: any) => socio.id == id);

    if (socio) {
      return socio.razon_social;
    }
    return '';
  }
  onInputChange() {
    if (
      this.tipoCriterio == 'juridica' ||
      this.tipoCriterio == 'sin juridica'
    ) {
      if (
        parseFloat(this.datos_p_juridica.porcentaje_participacion) <
        this.minParticipacionC
      ) {
        this.datos_p_juridica.porcentaje_participacion = String(
          this.minParticipacionC,
        );
      } else if (
        parseFloat(this.datos_p_juridica.porcentaje_participacion) >
        this.maxParticipacionC
      ) {
        this.datos_p_juridica.porcentaje_participacion = String(
          this.maxParticipacionC,
        );
      }
    } else {
      if (parseFloat(this.datos_p_juridica.porcentaje_participacion) < 0) {
        this.datos_p_juridica.porcentaje_participacion = String(0);
      } else if (
        parseFloat(this.datos_p_juridica.porcentaje_participacion) > 100
      ) {
        this.datos_p_juridica.porcentaje_participacion = String(100);
      }
    }
  }
  onInputChangeBeneficios() {
    if (this.tipoCriterio != null) {
      if (
        parseFloat(this.datos_p_juridica.porcentaje_beneficios) <
        this.minParticipacionB
      ) {
        this.datos_p_juridica.porcentaje_beneficios = String(
          this.minParticipacionB,
        );
      } else if (
        parseFloat(this.datos_p_juridica.porcentaje_beneficios) >
        this.maxParticipacionB
      ) {
        this.datos_p_juridica.porcentaje_beneficios = String(
          this.maxParticipacionB,
        );
      }
    } else {
      if (parseFloat(this.datos_p_juridica.porcentaje_beneficios) < 0) {
        this.datos_p_juridica.porcentaje_beneficios = String(0);
      } else if (
        parseFloat(this.datos_p_juridica.porcentaje_beneficios) > 100
      ) {
        this.datos_p_juridica.porcentaje_beneficios = String(100);
      }
    }
  }
  validateSociosJuridicos() {
    const exist = this.form.socios_accionistas.socios_indirectos[
      this.index
    ].socios.some((socio) => {
      return (
        (socio.tipo_persona == 'juridica' ||
          socio.tipo_persona == 'sin juridica') &&
        (socio.participacion_capital >= 5 ||
          socio.beneficios_rendimientos_utilidades >= 5)
      );
    });
    this.existPersonaJuridica = exist;
    return exist;
  }
  validateDesgloseSocios() {
    let cont = 0;
    for (let i = 0; i < this.selectSocios.length; i++) {
      const exist = this.form.socios_accionistas.socios_indirectos[
        this.index
      ].socios.some((socio) => {
        return socio.socio_superior == this.selectSocios[i].razon_social;
      });
      if (!exist) {
        cont++;
      }
    }
    if (cont > 0) {
      this.existDesgloseActive = true;
    } else {
      this.existDesgloseActive = false;
    }
  }
  validateCriterioJuridico(request: string, criterio?: any) {
    if (!this.updateActiveCriterio) {
      this.datos_p_juridica.porcentaje_participacion = String(0);
      this.datos_p_juridica.porcentaje_beneficios = String(0);
    } else {
      this.datos_p_juridica.criterio_determinacion_bf = criterio;
      if (request == 'SI') {
        request = 'NO';
      } else {
        request = 'SI';
      }
    }
    this.updateActiveCriterio = false;
    if (request == 'NO') {
      if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[0]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de beneficio en rendimiento y utilidades debe ser igual a 0 no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 100, 0);
      } else if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[1] ||
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[2] ||
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[4]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital y Porcentaje de beneficio en rendimiento y utilidades deben ser iguales a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 0, 0);
      } else if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[3]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital debe ser igual a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';
        this.chageMinAndMax(0, 0, 0, 100);
      } else if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_no[5]
      ) {
        this.chageMinAndMax(0, 0, 100, 100);
      }
    } else if (request == 'SI') {
      if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[0]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de beneficio en rendimiento y utilidades debe ser igual a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 100, 0);
      } else if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[1] ||
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[5]
      ) {
        this.chageMinAndMax(0, 0, 100, 100);
      } else if (
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[2] ||
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[3] ||
        this.datos_p_juridica.criterio_determinacion_bf ==
        criterio_determinacion_si[4]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital y Porcentaje de beneficio en rendimiento y utilidades deben ser iguales a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 0, 0);
      }
    }
  }
  validateCriterio(request: string, criterio?: any) {
    if (!this.updateActiveCriterio) {
      this.datos_p_natural.porcentaje_participacion = String(0);
      this.datos_p_natural.porcentaje_beneficios = String(0);
    } else {
      this.datos_p_natural.criterio_determinacion_bf = criterio;
      if (request == 'SI') {
        request = 'NO';
      } else {
        request = 'SI';
      }
    }
    this.updateActiveCriterio = false;
    if (request == 'NO') {
      if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[0]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de beneficio en rendimiento y utilidades debe ser igual a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 100, 0);
      } else if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[1] ||
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[2] ||
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[4]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital y Porcentaje de beneficio en rendimiento y utilidades deben ser iguales a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 0, 0);
      } else if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[3]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital debe ser igual a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';
        this.chageMinAndMax(0, 0, 0, 100);
      } else if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_no[5]
      ) {
        this.chageMinAndMax(0, 0, 100, 100);
      }
    } else if (request == 'SI') {
      if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[0]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de beneficio en rendimiento y utilidades debe ser igual a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 100, 0);
      } else if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[1] ||
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[5]
      ) {
        this.chageMinAndMax(0, 0, 100, 100);
      } else if (
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[2] ||
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[3] ||
        this.datos_p_natural.criterio_determinacion_bf ==
        criterio_determinacion_si[4]
      ) {
        this.showActivePopUp(true);
        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'Porcentaje de participación en el capital y Porcentaje de beneficio en rendimiento y utilidades deben ser iguales a 0, no se aceptan otros valores ';
        this.MessaggePopUp.tipe = 'alert';

        this.chageMinAndMax(0, 0, 0, 0);
      }
    }
  }
  chageMinAndMax(min1, min2, max1, max2) {
    this.minParticipacionC = min1;
    this.minParticipacionB = min2;
    this.maxParticipacionC = max1;
    this.maxParticipacionB = max2;
  }
  onInputChangeCriterio() {
    if (
      parseFloat(this.datos_p_natural.porcentaje_participacion) <
      this.minParticipacionC
    ) {
      this.datos_p_natural.porcentaje_participacion = String(
        this.minParticipacionC,
      );
    } else if (
      parseFloat(this.datos_p_natural.porcentaje_participacion) >
      this.maxParticipacionC
    ) {
      this.datos_p_natural.porcentaje_participacion = String(
        this.maxParticipacionC,
      );
    }
  }
  onInputChangeBeneficiosCriterio() {
    if (
      parseFloat(this.datos_p_natural.porcentaje_beneficios) <
      this.minParticipacionB
    ) {
      this.datos_p_natural.porcentaje_beneficios = String(
        this.minParticipacionB,
      );
    } else if (
      parseFloat(this.datos_p_natural.porcentaje_beneficios) >
      this.maxParticipacionB
    ) {
      this.datos_p_natural.porcentaje_beneficios = String(
        this.maxParticipacionB,
      );
    }
  }
  checkDv1(input: any) {
    if (this.datos_p_natural.tipo_identificacion == 'NIT' && input == 1) {
      this.datos_p_natural.dv = this.calculateDV(
        this.datos_p_natural.numero_identificacion,
      );
    }
    if (this.datos_p_juridica.tipo_identificacion == 'NIT' && input == 2) {
      this.datos_p_juridica.dv = this.calculateDV(
        this.datos_p_juridica.numero_identificacion,
      );
    }
  }

  calculateDV(numNit: any) {
    var vpri, x, y, z;
    let stringNit = numNit.toString();
    // Se limpia el N
    // Se valida el nit
    if (isNaN(numNit)) {
      alert("El nit/cédula '" + numNit + "' no es válido(a).");
      return '';
    }

    // Procedimiento
    vpri = new Array(16);
    z = stringNit.length;

    vpri[1] = 3;
    vpri[2] = 7;
    vpri[3] = 13;
    vpri[4] = 17;
    vpri[5] = 19;
    vpri[6] = 23;
    vpri[7] = 29;
    vpri[8] = 37;
    vpri[9] = 41;
    vpri[10] = 43;
    vpri[11] = 47;
    vpri[12] = 53;
    vpri[13] = 59;
    vpri[14] = 67;
    vpri[15] = 71;

    x = 0;
    y = 0;
    for (var i = 0; i < z; i++) {
      y = stringNit.substr(i, 1);

      x += y * vpri[z - i];
    }

    y = x % 11;

    return y > 1 ? 11 - y : y;
  }

  changeCriterios() {
    if (this.nivel == '1') {
      this.form.socios_accionistas.socios_directos.forEach((socio: any) => {
        if (socio.razon_social == this.add_socio.socio_superior) {
          this.tipoCriterio = socio.tipo_persona;
        }
      });
    } else {
      this.form.socios_accionistas.socios_indirectos[
        this.index - 1
      ].socios.forEach((socio: any) => {
        if (socio.razon_social == this.add_socio.socio_superior) {
          this.tipoCriterio = socio.tipo_persona;
        }
      });
    }
  }
}
