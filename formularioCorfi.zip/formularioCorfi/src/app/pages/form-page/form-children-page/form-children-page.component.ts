import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { FormService } from '../../../services/form.service';
import { formData } from 'src/app/utils/form.utils';
import { IForms } from 'src/app/utils/formsData';

@Component({
  selector: 'app-form-children-page',
  templateUrl: './form-children-page.component.html',
  styleUrls: ['./form-children-page.component.scss'],
})
export class FormChildrenPageComponent implements OnInit {
  formsD: IForms | any = {};
  formCode: any = '';
  stepNavigator = 1;
  dataForm = formData;
  loader = true;
  page1Valide = false;
  page2Valide = false;
  page3Valide = false;

  formID = ''
  termsandcodditions: any = '';
  status: 'init' | 'process' | 'failed' | 'valid' | void = 'init';
  constructor(
    private authService: AuthService,
    private _route: ActivatedRoute,
    private formService: FormService,
    private router: Router,
  ) {
    this.formCode = this._route.snapshot.paramMap.get('code');
  }
  ngOnInit(): void {

    // this.ValidCode();
    this.getFormData();
  }
  changeStep(step: string) {
    this.stepNavigator = parseInt(step);
  }
  async getFormData() {
    this.formsD = await this.formService.getForms();
    // console.log("entro", this.formsD, this.formCode)
    if (this.formsD) {
      let index = this.formsD.forms.findIndex((f: any) => f.id === this.formCode);
      if (this.formsD.forms[index]) {

        this.status = 'valid';
        this.dataForm = this.formsD.forms[index]
        if (this.dataForm.activate_anexo == 'SI') {
          this.stepNavigator = 4;
        }
      } else {

        this.status = 'failed';
      }
      // this.dataForm = form;

    } else {

      this.status = 'failed';
    }
    setTimeout(() => {
      this.termsandcodditions = localStorage.getItem('termsandcodditions');

      this.loader = false;
    }, 1000);
  }
  ValidCode() {
    const dataCode = this.authService.validUserCode(this.formCode);

    if (dataCode != false) {
      this.status = 'valid';
      this.termsandcodditions = localStorage.getItem('termsandcodditions');
    } else {
      this.status = 'failed';
    }
    setTimeout(() => {
      this.loader = false;
    }, 1000);
  }
}
