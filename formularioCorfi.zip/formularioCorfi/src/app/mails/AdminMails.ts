import emailAdmin from '../config/email';
// import settings from "../config/settings";

const nodemailer = require('nodemailer');

const createMailTransporter = () => {
  const transporter = nodemailer.createTransport({
    host: emailAdmin.HOST,

    port: emailAdmin.PORT,
    auth: {
      user: emailAdmin.EMAIL,
      pass: emailAdmin.PASS,
    },
  });
  return transporter;
};

const sendMailResetPassword = (
  adminData: any,
  password: string,
  // urlDom: string
) => {
  const mailOptions = {
    from: emailAdmin.EMAIL, // Remitente del correo
    to: adminData.admin_email, // Destinatario del correo
    subject: 'REfresh de contraseña Corficolombiana',
    html: `
    <p>Hola 👋 ${adminData.admin_name}, Tu nueva contraseña es..</p>
    <br>
    <p>Contraseña generada</p>
    <p>${password}</p>
    <p>Esta contraseña es valida durante 2 dias</p>
    `,
  };
  const transporter = createMailTransporter();
  transporter.sendMail(mailOptions, (error: any, info: any) => {
    if (error) {
      console.error('Error al enviar el correo:', error);
    } else {
      console.log('Correo enviado:', info.response);
    }
  });
};
const sendMailCreateAdmin = (
  adminData: any,
  password: string,
  // urlDom: string
) => {
  const mailOptions = {
    from: emailAdmin.EMAIL, // Remitente del correo
    to: adminData.admin_email, // Destinatario del correo
    subject: 'Codigo de verificacion Corficolombiana',
    html: `
    <p>Hola 👋 ${adminData.admin_name}, Se ha creado un nuevo administrador con tu correo</p>
    <br>
    <p>Tu Contraseña es: </p>
    <p>${password}</p>
    <p>Y Su codigo de acceso </p>
    <p>${adminData.admin_code}</p>
    <br>
    <p>Esta contraseña reincia cada 2 dias </p>
    `,
  };
  const transporter = createMailTransporter();
  transporter.sendMail(mailOptions, (error: any, info: any) => {
    if (error) {
      console.error('Error al enviar el correo:', error);
    } else {
      console.log('Correo enviado:', info.response);
    }
  });
};
// const sendMailEmailValid = (
//   userData: any,
//   url: string
//   // urlDom: string
// ) => {
//   const mailOptions = {
//     from: emailAdmin.EMAIL, // Remitente del correo
//     to: userData.user_email, // Destinatario del correo
//     subject: "Verificacion de correo electronico Corficolombiana",
//     html: `
//     <p>Hola 👋 ${userData.firstname}, verifica tu correo en el siguiente link...</p>
//     <br>
//     <a href="${url}/${userData.emailToken}"></a>
//     `,
//   };
//   const transporter = createMailTransporter();
//   transporter.sendMail(mailOptions, (error: any, info: any) => {
//     if (error) {
//       console.error("Error al enviar el correo:", error);
//     } else {
//       console.log("Correo enviado:", info.response);
//     }
//   });
// };
module.exports = {
  sendMailResetPassword,
  sendMailCreateAdmin,
  // sendMailEmailValid,
};
