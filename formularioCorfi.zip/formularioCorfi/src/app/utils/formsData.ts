export interface IForms {
  code: string;
  forms: IForm[];
}
export interface IForm {
  id: string;
  fecha_create: string;
  estado: 'resuelto' | 'proceso';
}
export const formsData: IForms = {
  code: '',
  forms: [{
    id: '',
    fecha_create: '',
    estado: 'proceso'
  }],
};

export let UserData = {
  nombre: '',
  firma: '',

}
export const tiposDocumentos = [
  {
    code: ' CC',
    name: 'cédula de ciudadanía',
  },
  { code: 'CE', name: 'cédula de extranjería' },
  { code: 'TI', name: 'Tarjeta de identidad' },
  { code: 'RC', name: 'Registro civil' },
  { code: 'PB', name: 'Pasaporte' },
  { code: 'PA', name: 'Patrimonio autónomo' },
  { code: 'NIT', name: 'NIT' },
];
