import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardSocioDirectoComponent } from './card-socio-directo.component';

describe('CardSocioDirectoComponent', () => {
  let component: CardSocioDirectoComponent;
  let fixture: ComponentFixture<CardSocioDirectoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CardSocioDirectoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CardSocioDirectoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
