import { Component } from '@angular/core';
import { primaryButtons } from 'src/app/utils/colors';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
})
export class HomePageComponent {
  colorsButtons = primaryButtons;
  descargarPDF() {
    const rutaPDF = '/assets/pdf/formulario.pdf'; // Ruta relativa al archivo PDF dentro de la carpeta "assets"
    const link = document.createElement('a');
    link.href = rutaPDF;
    link.download = 'formulario_Titularidad_dian.pdf'; // Nombre del archivo de descarga
    link.click();
    URL.revokeObjectURL(rutaPDF);
  }
}
