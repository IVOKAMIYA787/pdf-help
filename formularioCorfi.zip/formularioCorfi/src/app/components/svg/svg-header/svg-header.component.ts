import { Component } from '@angular/core';

@Component({
  selector: 'app-svg-header',
  templateUrl: './svg-header.component.html',
  styleUrls: ['./svg-header.component.scss']
})
export class SvgHeaderComponent {

}
