export const tipo_vinculacion = [
  'Solicitante',
  'Beneficiario',
  'Entidad financiera',
  'Intermediario',
  'Títular',
  'Fideicomiso',
  'Entidad estatal',
  'Cliente intermediario',
];
export const tipo_servicio = [
  'Fondo de Inversión Colectiva',
  'Fondo de Capital Privado',
  'Portafolio Inversión',
  'Banca de Inversión',
  'Mercados Globales',
  'Cuenta de Ahorros',
  'Bonos Ordinarios',
  'Fideicomisos',
  'Emisión Masiva',
  'Derivados',
  'Ómnibus',
  'Tesorería',
  'Inversiones',
  'Crédito',
  'Divisas',
  'CDT',
  'APT',
  'Otro / ¿Cuál?',
];
export const conocimiento_invertir = [
  'No tengo conocimiento ni experiencia a la hora de invertir',
  'Tengo poco conocimiento, preferiría recibir orientación y asesoría en los temas de inversiones',
  'Tengo suficiente conocimiento, me siento seguro y tranquilo para entender los riesgos asociados a cada inversión y tomar decisiones',
  'Tengo mucho conocimiento, soy inversionista profesional',
];
export const horizonte_tiempo = [
  'Menos de 1 año',
  'Entre 1 y 3 años',
  'Entre 3 y 5 años',
  'Mayor a 5 años',
];
export const dinero_corresponde = [
  'Más del 50%',
  'Entre el 30% y el 50%',
  'Entre el 10% y el 30%',
  'Menos del 10%',
];
export const capacidad_asumir_perdidas = [
  'Por lo menos mantener mi capital inicial invertido',
  'Tolerar una pérdida del 10% de mi capital invertido',
  'Tolerar una pérdida del 30% de mi capital invertido',
  'Estaría dispuesto a tolerar cualquier pérdida de mi capital en 1 año',
];
export const nivel_riesgo = [
  'Muy Bajo: Su principal preocupación es la seguridad de su inversión. Prefiero estabilidad antes que crecimiento',
  'Bajo: Puedo tolerar variaciones leves en el capital en el corto plazo, para obtener crecimientos moderados en su inversión',
  'Mediano: Quiere que su capital crezca y está dispuesto a aceptar variaciones importantes en su capital en el corto plazo',
  'Alto: Su principal objetivo es el crecimiento del capital, asumiendo oportunidades de inversión agresivas, las Cuáles traen asociados  niveles de volatilidad altos y en consecuencia posibles variaciones representativas en su capital',
];
export const autorizo_entidad = [
  'Extractos',
  'Liquidación de Bolsa',
  'Extracto FIC',
  'Saldos Diarios',
  'Facturación Electrónica',
  'Rendición de Cuentas',
];
export const medio_envio = ['SWIFT MT940', 'E-mail', 'Físico'];
export const tipos_cuenta = ['Ahorros', 'Corriente'];
export const tipos_identidicacion = [
  { codigo: 'CC', label: 'CC: Cédula de ciudadanía' },
  { codigo: 'NT', label: 'NT: Nit' },
  { codigo: 'CE', label: 'CE: Cédula de Extranjería' },
  { codigo: 'PS', label: 'PS: Pasaporte' },
  { codigo: 'RC', label: 'RC: Registro Civil' },
  { codigo: 'TI', label: 'TI: Tarjeta de identidad' },
  { codigo: 'PDP', label: 'PDP: Permiso Especial de permanencia' },
  { codigo: 'CDIP', label: 'CDIP: Carnet Diplomático' },
  { codigo: 'PPT', label: 'PPT: Permiso por protecciones temporales' },
];
