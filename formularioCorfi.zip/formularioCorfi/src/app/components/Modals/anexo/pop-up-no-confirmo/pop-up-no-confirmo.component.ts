import { Component } from '@angular/core';

@Component({
  selector: 'app-pop-up-no-confirmo',
  templateUrl: './pop-up-no-confirmo.component.html',
  styleUrls: ['./pop-up-no-confirmo.component.scss']
})
export class PopUpNoConfirmoComponent {

}
