import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-tool5',
  templateUrl: './tool5.component.html',
  styleUrls: ['./tool5.component.scss'],
})
export class Tool5Component {
  @Output() showPopUp = new EventEmitter<boolean>();
  @Input() beneficiarop = 'NO';
  constructor() {}

  ngOnInit(): void {
    if (this.beneficiarop == 'juridica') {
      this.beneficiarop = 'NO';
    } else if (this.beneficiarop == 'sin juridica') {
      this.beneficiarop = 'SI';
    }
  }
  onClose() {
    // this.showPopUp = false;
    this.showPopUp.emit(false);
  }
}
