import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-td-socio-superior',
  templateUrl: './td-socio-superior.component.html',
  styleUrls: ['./td-socio-superior.component.scss'],
})
export class TdSocioSuperiorComponent implements OnInit {
  @Input() id = 0;
  @Input() selectSocios: any = [];
  razon_social = '';
  ngOnInit() {
    this.buscarSocio();
  }

  buscarSocio() {
    let socio = this.selectSocios.find(
      (socio: any) => socio.razon_social == this.id,
    );

    if (socio) {
      this.razon_social = socio.razon_social;
    }
  }
}
