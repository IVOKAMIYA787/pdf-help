import { Component } from '@angular/core';

@Component({
  selector: 'app-tool4',
  templateUrl: './tool4.component.html',
  styleUrls: ['./tool4.component.scss'],
})
export class Tool4Component {
  isVisible: boolean = false;

  showTooltip() {
    this.isVisible = true;
  }

  hideTooltip() {
    this.isVisible = false;
  }
}
