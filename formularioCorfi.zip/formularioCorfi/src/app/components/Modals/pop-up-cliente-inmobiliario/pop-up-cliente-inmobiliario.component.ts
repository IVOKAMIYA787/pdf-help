import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-pop-up-cliente-inmobiliario',
  templateUrl: './pop-up-cliente-inmobiliario.component.html',
  styleUrls: ['./pop-up-cliente-inmobiliario.component.scss'],
})
export class PopUpClienteInmobiliarioComponent {
  @Input() status = false;

  closedModal() {
    this.status = false;
  }
}
