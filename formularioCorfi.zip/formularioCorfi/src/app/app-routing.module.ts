import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormPageComponent } from './pages/form-page/form-page.component';
import { rutas } from './rutas/rutas';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { CodeAccessPageComponent } from './pages/code-access-page/code-access-page.component';
import { CheckCodeGuard } from './guards/check-code.guard';
import { RedirectGuard } from './guards/redirect.guard';
import { FormChildrenPageComponent } from './pages/form-page/form-children-page/form-children-page.component';
import { PdfPageComponent } from './pdf/pdf-page/pdf-page.component';
import { PdfAnexoComponent } from './pdf/pdf-anexo/pdf-anexo.component';

const routes: Routes = [
  // {
  //   path: rutas.home,
  //   canActivate: [CheckCodeGuard],
  //   component: HomePageComponent,
  // },
  // {
  //   path: rutas.form.home + '/:code/pdf',
  //   canActivate: [CheckCodeGuard],
  //   component: PdfPageComponent,
  // },
  // {
  //   path: rutas.form.home + '/:code/pdf-anexo',
  //   canActivate: [CheckCodeGuard],
  //   component: PdfAnexoComponent,
  // },
  // {
  //   path: rutas.code,
  //   canActivate: [RedirectGuard],
  //   component: CodeAccessPageComponent,
  // },
  {
    path: rutas.home,

    // canActivate: [CheckCodeGuard],
    component: FormPageComponent,
    // children: [{ path: ':id', component: FormChildrenPageComponent }],
  },
  {
    path: rutas.form.home + '/:code',

    // canActivate: [CheckCodeGuard],
    component: FormChildrenPageComponent,
  },
  // { path: '', redirectTo: rutas.home, pathMatch: 'full' },
  { path: '**', redirectTo: rutas.home, pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
