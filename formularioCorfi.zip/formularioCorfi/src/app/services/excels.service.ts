import { Injectable } from '@angular/core';

import * as XLSX from 'xlsx';
@Injectable({
  providedIn: 'root',
})
export class ExcelsService {
  ciiu: any = '';

  constructor() {}
  async getCountrys() {
    try {
      const response = await fetch('./assets/paises.xlsx');
      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
        type: 'array',
      });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const countries = XLSX.utils.sheet_to_json(worksheet, { raw: true });
      return countries;
    } catch (error) {
      console.error('Error al cargar el archivo Excel:', error);
      return null; // You might want to return an error or null value here.
    }
  }
  async getCitys() {
    try {
      const response = await fetch('./assets/ciudades.xlsx');
      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
        type: 'array',
      });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const countries = XLSX.utils.sheet_to_json(worksheet, { raw: true });
      return countries;
    } catch (error) {
      console.error('Error al cargar el archivo Excel:', error);
      return null; // You might want to return an error or null value here.
    }
  }
  async getDepartaments() {
    try {
      const response = await fetch('./assets/departamentos.xlsx');
      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
        type: 'array',
      });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const countries = XLSX.utils.sheet_to_json(worksheet, { raw: true });
      return countries;
    } catch (error) {
      console.error('Error al cargar el archivo Excel:', error);
      return null; // You might want to return an error or null value here.
    }
  }
}
