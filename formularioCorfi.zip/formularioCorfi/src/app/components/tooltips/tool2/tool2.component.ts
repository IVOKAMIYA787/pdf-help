import { Component } from '@angular/core';

@Component({
  selector: 'app-tool2',
  templateUrl: './tool2.component.html',
  styleUrls: ['./tool2.component.scss'],
})
export class Tool2Component {
  isVisible: boolean = false;

  showTooltip() {
    this.isVisible = true;
  }

  hideTooltip() {
    this.isVisible = false;
  }
}
