import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { EmailsService } from './emails.service';
import { IForms } from '../utils/formsData';
@Injectable({
  providedIn: 'root',
})
export class FormService {
  constructor(private emailsService: EmailsService) { }


  saveFormSocios(sociosData: any) {
    const form = CryptoJS.AES.encrypt(
      JSON.stringify(sociosData),
      environment.SECRET.trim(),
    ).toString();
    localStorage.setItem('socios', form);
  }
  getSocios() {
    const form: any = localStorage.getItem('socios');
    if (form) {
      const code = CryptoJS.AES.decrypt(
        form,
        environment.SECRET.trim(),
      ).toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(code);
      return data;
    } else {
      return false;
    }
  }
  getForm() {
    const form: any = localStorage.getItem('forms');
    if (form) {
      const code = CryptoJS.AES.decrypt(
        form,
        environment.SECRET.trim(),
      ).toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(code);
      return data;
    } else {
      return false;
    }
  }
  getForms(): any | null {
    if (typeof localStorage !== 'undefined') {
      const forms: any = localStorage.getItem('forms');
      if (forms) {
        try {
          const decrypted = CryptoJS.AES.decrypt(
            forms,
            environment.SECRET.trim()
          ).toString(CryptoJS.enc.Utf8);
          const data = JSON.parse(decrypted);
          // console.log('data', data);

          let fechaActual = new Date().getTime();
          if (data.fecha_expiracion < fechaActual) {
            localStorage.clear();
            alert("Se han borrado los formularios automáticamente, porque han pasado mas de 30 días ")
          }
          return data;
        } catch (e) {
          console.error('Error decrypting token from localStorage', e);
          return false;
        }
      } else {
        return false;
      }
    }
    return null;
  }
  saveForm(code: string) {
    let formData = { code: code, forms: [] };
    const form = CryptoJS.AES.encrypt(
      JSON.stringify(formData),
      environment.SECRET.trim()
    ).toString();
    localStorage.setItem('forms', form);
  }
  saveFormData(formData: any) {
    const form = CryptoJS.AES.encrypt(
      JSON.stringify(formData),
      environment.SECRET.trim()
    ).toString();
    localStorage.setItem('forms', form);
  }
  saveFormDataFId(formData: any, id: string, status?: boolean) {
    let form: IForms = this.getForm()
    let index = form.forms.findIndex((f: any) => f.id === id);
    form.forms[index] = formData
    if (status == true) {
      form.forms[index].estado = 'resuelto'
    }
    const formSave = CryptoJS.AES.encrypt(
      JSON.stringify(form),
      environment.SECRET.trim()
    ).toString();
    localStorage.setItem('forms', formSave);
  }
}
