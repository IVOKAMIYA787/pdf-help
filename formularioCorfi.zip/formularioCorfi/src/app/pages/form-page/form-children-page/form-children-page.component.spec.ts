import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormChildrenPageComponent } from './form-children-page.component';

describe('FormChildrenPageComponent', () => {
  let component: FormChildrenPageComponent;
  let fixture: ComponentFixture<FormChildrenPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FormChildrenPageComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(FormChildrenPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
