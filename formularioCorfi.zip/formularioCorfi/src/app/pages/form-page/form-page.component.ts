import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { EmailsService } from 'src/app/services/emails.service';
import { rutas } from 'src/app/rutas/rutas';
import { FormService } from 'src/app/services/form.service';
import { formsData } from 'src/app/utils/formsData';
import * as moment from 'moment';
import { formData } from 'src/app/utils/form.utils';

@Component({
  selector: 'app-form-page',
  templateUrl: './form-page.component.html',
  styleUrls: ['./form-page.component.scss'],
})
export class FormPageComponent implements OnInit {
  rutas = rutas;
  email: any = '';

  fechaFormateada: string = '';

  loader = false;
  formsD = {
    code: '',
    fecha_expiracion: 0,
    forms: [],
  };
  showModalForms = false;
  showModalUserData = false
  showModalPDF = false;
  formModalData: any;
  addForm = false
  termsandcodditions: any = '';
  status: 'init' | 'process' | 'failed' | 'valid' | void = 'init';

  ShowPopUp = false;
  MessaggePopUp = {
    titulo: 'titulo',
    descripcion: 'texto explicativo',
    tipe: 'simple',
  };
  constructor(
    private route: ActivatedRoute,
    private formService: FormService,

    private elementRef: ElementRef,
    private router: Router
  ) { }
  ngAfterViewInit(): void {

  }
  ngOnInit(): void {
    this.getForm();
    // this.startTour();

  }
  async getForm() {
    const form = this.formService.getForms();

    if (form) {
      this.formsD = form

    } else {

      let fechaActual = new Date().getTime();
      this.formsD.fecha_expiracion = new Date(fechaActual + 30 * 86400000).getTime();

    }
    setTimeout(() => {

      this.loader = true;

      this.status = 'valid';
      this.termsandcodditions = localStorage.getItem('termsandcodditions');
      // const storedValue = localStorage.getItem('tutorialActivate' || null);

      // this.startTour();
    }, 2000);

    // console.log(this.formsD);
  }
  showActivePopUp(status: boolean) {
    this.ShowPopUp = status;
  }
  openModal(status: boolean) {
    this.showModalForms = status;
  }
  openModalUser(status: boolean) {
    this.showModalUserData = status
  }
  openModalPDF(status: boolean, form?: any) {
    // console.log("ff", form)
    if (!status) {
      this.showModalPDF = status;
    } else {
      if (form?.estado == 'resuelto') {
        this.showModalPDF = status;
        if (form) {
          this.formModalData = form;
        } else {
          this.formModalData = [];
        }
      } else {
        this.showActivePopUp(true);

        this.MessaggePopUp.titulo = 'Alerta';
        this.MessaggePopUp.descripcion =
          'El formulario se encuentra en proceso, diligéncialo para poder descargarlo.';
        this.MessaggePopUp.tipe = 'alert';
      }
    }

  }
  addform() {

    // console.log(this.formsD);
    const uniqueId = this.generateUniqueId();
    this.getDate();
    let newForm = formData
    newForm.id = uniqueId
    newForm.fecha_create = this.fechaFormateada,
      newForm.estado = 'proceso',
      this.formsD.forms.push(newForm);
    this.formService.saveFormData(this.formsD);
    const ruta = '/form/' + uniqueId;

    this.router.navigateByUrl(ruta);
  }
  onClickUpdateForm(id: string) {
    const ruta = '/form/' + id;

    this.router.navigateByUrl(ruta);
  }
  deleteForm(id: string) {
    const index = this.formsD.forms.findIndex((item) => item.id === id);
    if (index !== -1) {
      this.formsD.forms.splice(index, 1);
    }

    this.formService.saveFormData(this.formsD);
  }
  getDate() {
    const timestampMs = new Date().getTime();

    // Configura Moment.js para usar español
    moment.updateLocale('es', {
      months: [
        'enero',
        'febrero',
        'marzo',
        'abril',
        'mayo',
        'junio',
        'julio',
        'agosto',
        'septiembre',
        'octubre',
        'noviembre',
        'diciembre',
      ],
      monthsShort: [
        'ene',
        'feb',
        'mar',
        'abr',
        'may',
        'jun',
        'jul',
        'ago',
        'sep',
        'oct',
        'nov',
        'dic',
      ],
      weekdays: [
        'domingo',
        'lunes',
        'martes',
        'miércoles',
        'jueves',
        'viernes',
        'sábado',
      ],
      weekdaysShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
      weekdaysMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
      longDateFormat: {
        LT: 'H:mm',
        LTS: 'H:mm:ss',
        L: 'DD/MM/YYYY',
        LL: 'D [de] MMMM [de] YYYY',
        LLL: 'D [de] MMMM [de] YYYY H:mm',
        LLLL: 'dddd, D [de] MMMM [de] YYYY H:mm',
      },
    });

    // Convierte y formatea la fecha
    this.fechaFormateada = moment(timestampMs).format(
      'dddd, D [de] MMMM [de] YYYY HH:mm:ss'
    );
  }
  generateUniqueId(): string {
    const timestamp = new Date().getTime().toString(36); // Base 36 encoding of timestamp
    const randomSuffix = Math.random().toString(36).substr(2, 9); // Random alphanumeric string
    return `${timestamp}-${randomSuffix} `;
  }
}
