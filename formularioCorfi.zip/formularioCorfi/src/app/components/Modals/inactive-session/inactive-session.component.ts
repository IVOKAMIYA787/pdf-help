import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { rutas } from 'src/app/rutas/rutas';

@Component({
  selector: 'app-inactive-session',
  templateUrl: './inactive-session.component.html',
  styleUrls: ['./inactive-session.component.scss'],
})
export class InactiveSessionComponent {
  private inactivityTimer: any = 0;
  countdown: number = 90;
  private readonly INACTIVITY_TIMEOUT = 5 * 60 * 1000; // 2 minutos
  status = false;
  inter: any = 0;
  constructor(private router: Router) {
    this.resetInactivityTimer();

    document.addEventListener('mousemove', () => this.resetInactivityTimer());
    document.addEventListener('keypress', () => this.resetInactivityTimer());
  }
  startCountdown() {
    this.inter = setInterval(() => {
      this.countdown--;
      console.log(1);
      if (this.countdown === 0) {
        clearInterval(this.inter);
        this.logout();
      }
    }, 1000);
  }
  resetInactivityTimer() {
    clearTimeout(this.inactivityTimer);
    this.inactivityTimer = setTimeout(() => {
      this.status = true;
      this.startCountdown();
    }, this.INACTIVITY_TIMEOUT);
  }
  logout() {
    // this.router.navigate(['']);
    window.location.href = 'https://www.corficolombiana.com/';
  }
  closedModal() {
    this.countdown = 90;
    this.status = false;
    clearInterval(this.inter);
  }
}
