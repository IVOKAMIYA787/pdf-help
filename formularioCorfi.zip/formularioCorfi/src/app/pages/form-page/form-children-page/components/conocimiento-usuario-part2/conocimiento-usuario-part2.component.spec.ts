import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConocimientoUsuarioPart2Component } from './conocimiento-usuario-part2.component';

describe('ConocimientoUsuarioPart2Component', () => {
  let component: ConocimientoUsuarioPart2Component;
  let fixture: ComponentFixture<ConocimientoUsuarioPart2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConocimientoUsuarioPart2Component],
    }).compileComponents();

    fixture = TestBed.createComponent(ConocimientoUsuarioPart2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
