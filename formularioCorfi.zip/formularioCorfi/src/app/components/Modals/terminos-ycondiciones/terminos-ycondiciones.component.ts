import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { primaryButtons } from 'src/app/utils/colors';
@Component({
  selector: 'app-terminos-ycondiciones',
  templateUrl: './terminos-ycondiciones.component.html',
  styleUrls: ['./terminos-ycondiciones.component.scss'],
})
export class TerminosYCondicionesComponent {
  colorButtons = primaryButtons;
  constructor(private router: Router) {}
  deleteAll() {
    localStorage.clear();
    this.router.navigate(['']);
  }
  acepTerms() {
    localStorage.setItem('termsandcodditions', 'true');

    window.location.reload();
  }
}
