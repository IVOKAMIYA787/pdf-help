import { Component } from '@angular/core';

@Component({
  selector: 'app-loader-full-page',
  templateUrl: './loader-full-page.component.html',
  styleUrls: ['./loader-full-page.component.scss'],
})
export class LoaderFullPageComponent {}
