import { Component, Input } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-no-sujeto-renta',
  templateUrl: './no-sujeto-renta.component.html',
  styleUrls: ['./no-sujeto-renta.component.scss'],
})
export class NoSujetoRentaComponent {
  @Input() status = false;
  @Input() form: any;

  submitInvalid = false;
  closedModal() {
    this.status = false;
  }
  validText(step1Form: NgForm) {
    if (step1Form.valid) {
      this.submitInvalid = false;
      this.closedModal();
    } else {
      this.submitInvalid = true;
    }
  }
}
