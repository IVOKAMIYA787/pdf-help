export const criterio_determinacion_no = [
  '1.Fiduciante / Fideicomitente / Constituyente o posición similar o equivalente',
  '2.Fiduciario o posición similar o equivalente',
  '3.Comité financiero o posición similar o equivalente',
  '4.Fideicomisario / Beneficiario',
  '5.Ejerce el control final y/o efectivo o tiene derecho a gozar y/o disponer de los activos, beneficios, resultados o utilidades',
  '6.Fideicomitente y Beneficiario',
];
export const criterio_determinacion_si = [
  '1. Titularidad y/o derechos a voto.',
  '2. Beneficiario de los activos, rendimientos o utilidades ',
  '3. Control diferente a los establecidos en numerales 1 y 2.',
  '4. Representante legal',
  '5. Persona natural que ostenta mayor autoridad en relación con las funciones de gestión o dirección de la persona jurídica.',
  '6. Tiene la Titularidad y/o derechos a voto y  es  Beneficiario de los activos, rendimientos o utilidades. ',
];
