import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  tipo_vinculacion,
  tipo_servicio,
  conocimiento_invertir,
  horizonte_tiempo,
  dinero_corresponde,
  capacidad_asumir_perdidas,
  nivel_riesgo,
  autorizo_entidad,
  medio_envio,
  tipos_cuenta,
  tipos_identidicacion,
} from 'src/app/utils/selectsAnexo';
import {
  id_persona_natural,
  id_persona_normal,
} from 'src/app/utils/selectVinculacion';
import { NgForm } from '@angular/forms';
import { FormService } from 'src/app/services/form.service';
@Component({
  selector: 'app-anexo-page1',
  templateUrl: './anexo-page1.component.html',
  styleUrls: ['./anexo-page1.component.scss'],
})
export class AnexoPage1Component {
  showDowloadPDF = false;
  @Input() form: any;

  @Input() formId = ''
  ShowPopUp = false;
  tipos_cuenta: any = tipos_cuenta;
  tipos_identidicacion = tipos_identidicacion;
  autorizo_entidad: any = autorizo_entidad;
  medio_envio: any = medio_envio;
  tipo_vinculacion: any = tipo_vinculacion;
  tipo_servicio = tipo_servicio;
  conocimiento_invertir = conocimiento_invertir;
  horizonte_tiempo = horizonte_tiempo;
  dinero_corresponde = dinero_corresponde;
  capacidad_asumir_perdidas = capacidad_asumir_perdidas;
  nivel_riesgo = nivel_riesgo;

  id_persona_natural = id_persona_natural;
  id_persona_normal = [
    'NUIP',
    'Tarjeta de identidad',
    'Cédula de ciudadanía',
    'Tarjeta de extranjería',
    'Cédula de extranjería',
    'Pasaporte',
    'Tipo documento Extranjero',
    'Permiso Especial de Permanencia',
  ];
  dropdownList = [];
  selectedItems = [];
  submitInvalid = false;
  dropdownSettings = {};
  MessaggePopUp = {
    titulo: 'titulo',
    descripcion: 'texto explicativo',
    tipe: 'simple',
  };
  @Output() step = new EventEmitter<string>();

  constructor(private formService: FormService) { }
  validateForm(step1Form: NgForm) {
    // this.formService.saveForm(this.form);
    if (step1Form.valid) {
      this.submitInvalid = false;
      // this.formService.saveForm(this.form);

      this.formService.saveFormDataFId(this.form, this.formId, true);
      // this.step.emit('2');
      this.showDowloadPDF = true;
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Guardado';
      this.MessaggePopUp.descripcion =
        'Se ha guardado exitosamente, ya puedes generar tu pdf';
      this.MessaggePopUp.tipe = 'simple';
    } else {
      this.submitInvalid = true;
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.showDowloadPDF = false;
      this.MessaggePopUp.descripcion =
        'Hay campos sin diligenciar, verificar para continuar. *Los campos faltantes se muestran en rojo.';
      this.MessaggePopUp.tipe = 'alert';
    }
    // this.submitInvalid = true;
  }
  showActivePopUp(status: boolean) {
    this.ShowPopUp = status;
  }
  validateSuperfinanciera() {
    if (this.form.activate_anexo == 'NO') {
      this.step.emit('1');
    }
  }

  refreshCategoriaInversionista() {
    if (
      this.form.formato_anexo.categorizacion_inversionista
        .entidad_es_un_organismo_financiero_eom != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .ha_sido_clasificado_como_inversionista != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .entidad_es_vigilada_por_superintendencia != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .posee_experiencia_conocimientos != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .cuenta_con_patrimonio_igual_o_mayor != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .titular_de_un_portafolio != '' &&
      this.form.formato_anexo.categorizacion_inversionista
        .realizado_mas_operaciones != ''
    ) {
      if (
        this.form.formato_anexo.categorizacion_inversionista
          .entidad_es_un_organismo_financiero_eom == 'SI' ||
        this.form.formato_anexo.categorizacion_inversionista
          .ha_sido_clasificado_como_inversionista == 'SI' ||
        this.form.formato_anexo.categorizacion_inversionista
          .entidad_es_vigilada_por_superintendencia == 'SI'
        //   ) ||
        // (this.form.formato_anexo.categorizacion_inversionista
        //   .entidad_es_vigilada_por_superintendencia == 'SI' &&
        //   this.form.formato_anexo.categorizacion_inversionista
        //     .ha_sido_clasificado_como_inversionista == 'SI')
      ) {
        this.form.formato_anexo.categorizacion_inversionista.categoria_inversionista =
          'Inversionista Profesional';
      } else if (
        this.form.formato_anexo.categorizacion_inversionista
          .posee_experiencia_conocimientos == 'SI' &&
        this.form.formato_anexo.categorizacion_inversionista
          .cuenta_con_patrimonio_igual_o_mayor == 'SI' &&
        this.form.formato_anexo.categorizacion_inversionista
          .titular_de_un_portafolio == 'SI'
      ) {
        this.form.formato_anexo.categorizacion_inversionista.categoria_inversionista =
          'Inversionista Profesional';
      } else if (
        this.form.formato_anexo.categorizacion_inversionista
          .posee_experiencia_conocimientos == 'SI' &&
        this.form.formato_anexo.categorizacion_inversionista
          .cuenta_con_patrimonio_igual_o_mayor == 'SI' &&
        this.form.formato_anexo.categorizacion_inversionista
          .realizado_mas_operaciones == 'SI'
      ) {
        this.form.formato_anexo.categorizacion_inversionista.categoria_inversionista =
          'Inversionista Profesional';
      } else {
        this.form.formato_anexo.categorizacion_inversionista.categoria_inversionista =
          'Cliente Inversionista';
      }
    }
  }
  refreshPerfilRiesgo() {
    let points = 0;

    if (
      this.form.formato_anexo.perfil_riesgo_inversionista
        .refleja_su_conocimiento != '' &&
      this.form.formato_anexo.perfil_riesgo_inversionista.horizonte_tiempo !=
      '' &&
      this.form.formato_anexo.perfil_riesgo_inversionista.dinero_corresponde !=
      '' &&
      this.form.formato_anexo.perfil_riesgo_inversionista
        .capacidad_asumir_perdidas != '' &&
      this.form.formato_anexo.perfil_riesgo_inversionista.nivel_riesgo != '' &&
      this.form.formato_anexo.perfil_riesgo_inversionista.capacidad_economica !=
      ''
    ) {
      if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .refleja_su_conocimiento == this.conocimiento_invertir[0]
      ) {
        points = points + 10;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .refleja_su_conocimiento == this.conocimiento_invertir[1]
      ) {
        points = points + 15;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .refleja_su_conocimiento == this.conocimiento_invertir[2]
      ) {
        points = points + 20;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .refleja_su_conocimiento == this.conocimiento_invertir[3]
      ) {
        points = points + 25;
      }
      // horizonte tiempo
      if (
        this.form.formato_anexo.perfil_riesgo_inversionista.horizonte_tiempo ==
        this.horizonte_tiempo[0]
      ) {
        points = points + 10;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.horizonte_tiempo ==
        this.horizonte_tiempo[1]
      ) {
        points = points + 15;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.horizonte_tiempo ==
        this.horizonte_tiempo[2]
      ) {
        points = points + 20;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.horizonte_tiempo ==
        this.horizonte_tiempo[3]
      ) {
        points = points + 25;
      }

      // dinero corresponde
      if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .dinero_corresponde == this.dinero_corresponde[0]
      ) {
        points = points + 10;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .dinero_corresponde == this.dinero_corresponde[1]
      ) {
        points = points + 15;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .dinero_corresponde == this.dinero_corresponde[2]
      ) {
        points = points + 20;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .dinero_corresponde == this.dinero_corresponde[3]
      ) {
        points = points + 25;
      }
      //capacidad asumir perdidas
      if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .capacidad_asumir_perdidas == this.capacidad_asumir_perdidas[0]
      ) {
        points = points + 10;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .capacidad_asumir_perdidas == this.capacidad_asumir_perdidas[1]
      ) {
        points = points + 15;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .capacidad_asumir_perdidas == this.capacidad_asumir_perdidas[2]
      ) {
        points = points + 20;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .capacidad_asumir_perdidas == this.capacidad_asumir_perdidas[3]
      ) {
        points = points + 25;
      }

      // tolerancia al riesgo
      if (
        this.form.formato_anexo.perfil_riesgo_inversionista.nivel_riesgo ==
        this.nivel_riesgo[0]
      ) {
        points = points + 10;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.nivel_riesgo ==
        this.nivel_riesgo[1]
      ) {
        points = points + 50;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.nivel_riesgo ==
        this.nivel_riesgo[2]
      ) {
        points = points + 90;
      } else if (
        this.form.formato_anexo.perfil_riesgo_inversionista.nivel_riesgo ==
        this.nivel_riesgo[3]
      ) {
        points = points + 100;
      }
      //requerimientos garantias

      if (
        this.form.formato_anexo.perfil_riesgo_inversionista
          .capacidad_economica == 'SI'
      ) {
        points = points + 5;
      }

      //calculate points
      this.form.formato_anexo.perfil_riesgo_inversionista.puntaje = points;
      if (points <= 135) {
        this.form.formato_anexo.perfil_riesgo_inversionista.perfil_riesgo =
          'Perfil conservador';
      } else if (points > 135 && points <= 185) {
        this.form.formato_anexo.perfil_riesgo_inversionista.perfil_riesgo =
          'Perfil moderado';
      } else if (points > 185) {
        this.form.formato_anexo.perfil_riesgo_inversionista.perfil_riesgo =
          'Perfil agresivo';
      }
    }
  }
  deleteFuncionario(index: any) {
    this.form.formato_anexo.reglas_para_instruccion_ordenes_atravez_correo_telefono.otras_personas.splice(
      index,
      1,
    );
  }
  deleteEmail(index: any) {
    this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift.splice(
      index,
      1,
    );
  }
  deletePersona(index: any) {
    this.form.formato_anexo.confirmacion_de_operaciones.personas.splice(
      index,
      1,
    );
  }
  deleteEmailSwift(index: any) {
    this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift.splice(
      index,
      1,
    );
  }
  addFuncionario() {
    this.form.formato_anexo.reglas_para_instruccion_ordenes_atravez_correo_telefono.otras_personas.push(
      {
        nombre: '',
        documento: '',
        email: '',
      },
    );
  }
  addEmail() {
    this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift.push(
      {
        nombres_apellidos: '',
        correo: '',
      },
    );
  }
  addPersona() {
    this.form.formato_anexo.confirmacion_de_operaciones.personas.push({
      nombres_apellidos: '',
      tipo_id: '',
      numero_id: '',
      cargo: '',
      telefono: '',
      correo: '',
    });
  }
  addEmailSwift() {
    this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift.push(
      {
        nombres_apellidos: '',

        correo: '',
      },
    );
  }
  confirmarOperacion() {
    if (
      this.form.formato_anexo.confirmacion_de_operaciones
        .confirmar_realizar_pagos == 'NO'
    ) {
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'Al seleccionar la opción “No realizar confirmación” asume los riesgos de remitir información errada que no sea posible confirmar o la utilización indebida de los canales para el trámite de instrucciones y órdenes.';
      this.MessaggePopUp.tipe = 'alert';
    }
  }
  calculateDV(numNit: any) {
    var vpri, x, y, z;
    let stringNit = numNit.toString();
    // Se limpia el Nit
    // numNit = numNit.replace(/\s/g, ''); // Espacios
    // numNit = numNit.replace(/,/g, ''); // Comas
    // numNit = numNit.replace(/\./g, ''); // Puntos
    // numNit = numNit.replace(/-/g, ''); // Guiones

    // Se valida el nit
    if (isNaN(numNit)) {
      alert("El nit/cédula '" + numNit + "' no es válido(a).");
      return '';
    }

    // Procedimiento
    vpri = new Array(16);
    z = stringNit.length;

    vpri[1] = 3;
    vpri[2] = 7;
    vpri[3] = 13;
    vpri[4] = 17;
    vpri[5] = 19;
    vpri[6] = 23;
    vpri[7] = 29;
    vpri[8] = 37;
    vpri[9] = 41;
    vpri[10] = 43;
    vpri[11] = 47;
    vpri[12] = 53;
    vpri[13] = 59;
    vpri[14] = 67;
    vpri[15] = 71;

    x = 0;
    y = 0;
    for (var i = 0; i < z; i++) {
      y = stringNit.substr(i, 1);
      // console.log ( y + "x" + vpri[z-i] + ":" ) ;

      x += y * vpri[z - i];
      // console.log ( x ) ;
    }

    y = x % 11;

    return y > 1 ? 11 - y : y;
  }

  checkDv1(inputNum: number) {
    if (
      this.form.Informacion_cliente.datos_generales.tipo_documento == 'NIT' &&
      inputNum == 1
    ) {
      this.form.Informacion_cliente.datos_generales.dv = this.calculateDV(
        this.form.Informacion_cliente.datos_generales.documento,
      );
    } else if (
      this.form.Informacion_cliente.datos_generales.controlante
        .tipo_documento == 'NIT' &&
      inputNum == 2
    ) {
      this.form.Informacion_cliente.datos_generales.controlante.dv =
        this.calculateDV(
          this.form.Informacion_cliente.datos_generales.controlante.documento,
        );
    }
  }
  validateEnvio() {
    if (
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.medio_para_envio_informacion.includes(
        'Físico',
      ) &&
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.medio_para_envio_informacion.includes(
        'E-mail',
      )
    ) {
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.medio_para_envio_informacion =
        [];
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'En tipo de envió solo puede selecciona o E-mail o Físico, no los dos juntos. ';
      this.MessaggePopUp.tipe = 'alert';
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.ciudad =
        '';
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.departamento =
        '';
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.direccion_envio =
        '';
      // this.form.formato_anexo.autorizacion_envios_saldos_movimientos.fisico_swift =
      //   {
      //     direccion_envio: '',
      //     ciudad: '',
      //     departamento: '',
      //   };
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift =
        [
          {
            nombres_apellidos: '',
            correo: '',
          },
        ];
    }
    if (
      !this.form.formato_anexo.autorizacion_envios_saldos_movimientos.medio_para_envio_informacion.includes(
        'E-mail',
      )
    ) {
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.emails_swift =
        [
          {
            nombres_apellidos: '',
            correo: '',
          },
        ];
    }
    if (
      !this.form.formato_anexo.autorizacion_envios_saldos_movimientos.medio_para_envio_informacion.includes(
        'Físico',
      )
    ) {
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.ciudad =
        '';
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.departamento =
        '';
      this.form.formato_anexo.autorizacion_envios_saldos_movimientos.direccion_envio =
        '';
    }
  }
}
