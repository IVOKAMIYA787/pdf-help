import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { HeaderComponent } from './components/header/header.component';
import { FormPageComponent } from './pages/form-page/form-page.component';
import { ErrorPagesComponent } from './pages/error-pages/error-pages.component';
import { CodeAccessPageComponent } from './pages/code-access-page/code-access-page.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormChildrenPageComponent } from './pages/form-page/form-children-page/form-children-page.component';
import { TerminosYCondicionesComponent } from './components/Modals/terminos-ycondiciones/terminos-ycondiciones.component';
import { ErrorFormPageComponent } from './pages/form-page/form-children-page/components/error-form-page/error-form-page.component';

import { LoaderFullPageComponent } from './components/loader-full-page/loader-full-page.component';
import { ConocimientoUsuarioComponent } from './pages/form-page/form-children-page/components/conocimiento-usuario/conocimiento-usuario.component';
import { SociosAccionistasComponent } from './pages/form-page/form-children-page/components/socios-accionistas/socios-accionistas.component';
import { InactiveSessionComponent } from './components/Modals/inactive-session/inactive-session.component';
import { PopUpSimpleComponent } from './components/Modals/pop-up-simple/pop-up-simple.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ConocimientoUsuarioPart2Component } from './pages/form-page/form-children-page/components/conocimiento-usuario-part2/conocimiento-usuario-part2.component';
import { CardSocioDirectoComponent } from './pages/form-page/form-children-page/components/socios-accionistas/components/card-socio-directo/card-socio-directo.component';
import { CardSocioIndirectoComponent } from './pages/form-page/form-children-page/components/socios-accionistas/components/card-socio-indirecto/card-socio-indirecto.component';
import { PopUpAyudaComponent } from './components/Modals/pop-up-ayuda/pop-up-ayuda.component';
import { PdfPageComponent } from './pdf/pdf-page/pdf-page.component';
import { AnexoPage1Component } from './pages/form-page/form-children-page/components/anexo-page1/anexo-page1.component';
import { PopUpClienteInmobiliarioComponent } from './components/Modals/pop-up-cliente-inmobiliario/pop-up-cliente-inmobiliario.component';
import { Tool1Component } from './components/tooltips/tool1/tool1.component';
import { Tool2Component } from './components/tooltips/tool2/tool2.component';
import { Tool3Component } from './components/tooltips/tool3/tool3.component';
import { Tool4Component } from './components/tooltips/tool4/tool4.component';
import { NoSujetoRentaComponent } from './components/Modals/no-sujeto-renta/no-sujeto-renta.component';
import { PopUpArrendatarioPEIComponent } from './components/Modals/pop-up-arrendatario-pei/pop-up-arrendatario-pei.component';
import { PdfAnexoComponent } from './pdf/pdf-anexo/pdf-anexo.component';
import { PopUpSkipFormComponent } from './components/Modals/pop-up-skip-form/pop-up-skip-form.component';
import { PopUpNoConfirmoComponent } from './components/Modals/anexo/pop-up-no-confirmo/pop-up-no-confirmo.component';
import { Tool5Component } from './components/tooltips/tool5/tool5.component';
import { NumberFormatDirectiveComponent } from './components/formats/number-format-directive/number-format-directive.component';
import { PopUpVolverComponent } from './components/Modals/pop-up-volver/pop-up-volver.component';
import { TdSocioSuperiorComponent } from './pages/form-page/form-children-page/components/socios-accionistas/components/td-socio-superior/td-socio-superior.component';
import { PuntajeComponent } from './components/svg/puntaje/puntaje.component';
import { BeneficiarioNoComponent } from './components/svg/beneficiario-no/beneficiario-no.component';
import { SvgHeaderComponent } from './components/svg/svg-header/svg-header.component';
@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    HeaderComponent,
    FormPageComponent,
    ErrorPagesComponent,
    CodeAccessPageComponent,
    FooterComponent,
    FormChildrenPageComponent,
    TerminosYCondicionesComponent,
    ErrorFormPageComponent,
    LoaderFullPageComponent,
    ConocimientoUsuarioComponent,
    SociosAccionistasComponent,
    InactiveSessionComponent,
    PopUpSimpleComponent,
    ConocimientoUsuarioPart2Component,
    CardSocioDirectoComponent,
    CardSocioIndirectoComponent,
    PopUpAyudaComponent,
    TdSocioSuperiorComponent,
    PdfPageComponent,
    AnexoPage1Component,
    PopUpClienteInmobiliarioComponent,
    Tool1Component,
    Tool2Component,
    Tool3Component,
    Tool4Component,
    NoSujetoRentaComponent,
    PopUpArrendatarioPEIComponent,
    PdfAnexoComponent,
    PopUpSkipFormComponent,
    PopUpNoConfirmoComponent,
    Tool5Component,
    NumberFormatDirectiveComponent,
    PopUpVolverComponent,
    PuntajeComponent,
    BeneficiarioNoComponent,
    SvgHeaderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NgMultiSelectDropDownModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
