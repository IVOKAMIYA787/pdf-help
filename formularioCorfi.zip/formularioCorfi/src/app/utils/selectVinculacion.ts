export const id_persona_natural = [
  'NIT',
  'Sin identificación del extranjero',
  'Tipo de documento extranjero',
  'NUIP',
  'Tarjeta de identidad',
  'Cédula de ciudadanía',
  'Tarjeta de extranjería',
  'Cédula de extranjeria',
  'Pasaporte',
  'Permiso especial de permanecia',
];

export const id_persona_normal = [
  'NUIP',
  'Tarjeta de identidad',
  'Cédula de ciudadanía',
  'Tarjeta de extranjería',
  'Cédula de extranjería',
  'Pasaporte',
  'Tipo documento Extranjero',
  'Permiso Especial de Permanencia',
];
