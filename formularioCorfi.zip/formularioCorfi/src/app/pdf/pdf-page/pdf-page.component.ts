import {
  Component,
  ElementRef,
  QueryList,
  OnInit,
  ViewChild,
  ViewChildren,
  Input,
} from '@angular/core';
import { FormService } from 'src/app/services/form.service';
import { formData } from 'src/app/utils/form.utils';
import * as html2pdf from 'html2pdf.js';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-pdf-page',
  templateUrl: './pdf-page.component.html',
  styleUrls: ['./pdf-page.component.scss'],
})
export class PdfPageComponent implements OnInit {
  @Input() form = formData;
  formCode = '';

  @ViewChild('pagina1') pagina1!: ElementRef;
  @ViewChildren('pagina') paginas!: QueryList<ElementRef>;
  fechaActual: Date = new Date();
  fechaDi = '';
  loader = false;
  nombreRepresentante = '';
  pageIds = ['pagina1', 'pagina2'];
  pagesSocioDirecto = [];
  pagesSocioIndirecto = [];
  totalNumPages = 3;
  totalNumPagesSociosDirectos = 0;
  constructor(private formService: FormService,
    private _route: ActivatedRoute,) {
    this.formCode = this._route.snapshot.paramMap.get('code');
  }
  async ngOnInit() {
    await this.getFormData();
    let dia: number = this.fechaActual.getDate();
    let mes: number = this.fechaActual.getMonth() + 1; // Meses comienzan desde 0
    let anio: number = this.fechaActual.getFullYear() % 100;
    this.fechaDi = `${dia < 10 ? '0' : ''}${dia}-${mes < 10 ? '0' : ''}${mes}-${anio < 10 ? '0' : ''
      }${anio}`;
    this.nombreRepresentante =
      this.form.Informacion_cliente.representante_legal.primer_nombre +
      ' ' +
      this.form.Informacion_cliente.representante_legal.segundo_nombre +
      ' ' +
      this.form.Informacion_cliente.representante_legal.primer_apellido +
      ' ' +
      this.form.Informacion_cliente.representante_legal.segundo_apellido;

    // this.calculateSocios();
  }

  calculateSocios() {
    if (this.form.socios_accionistas.socios_directos.length > 0) {

    }
    let sociosDirectos = this.form.socios_accionistas.socios_directos;
    let sociosDirectosArray: any = this.separarSocios(sociosDirectos);
    this.createPagesSociosDirectos(sociosDirectosArray);
    if (this.form.formato_anexo.PEI == false) {

      let sociosIndirectos = this.form.socios_accionistas.socios_indirectos;
      this.calculateSociosIndirectos(sociosIndirectos);
    }
  }

  separarSocios(socios) {
    let pN = [];
    let pJ = [];

    if (
      socios.some(
        (socio) =>
          socio.tipo_persona === 'juridica' ||
          socio.tipo_persona === 'sin juridica',
      )
    ) {
      pJ = [{ tipo_persona: 'tituloJ' }];
    }
    if (socios.some((socio) => socio.tipo_persona === 'natural')) {
      pN = [{ tipo_persona: 'tituloN' }];
    }

    socios.forEach((socio) => {
      if (socio.tipo_persona === 'juridica') {
        pJ.push(socio);
      } else if (socio.tipo_persona === 'natural') {
        pN.push(socio);
      } else if (socio.tipo_persona === 'sin juridica') {
        pJ.push(socio);
      }
    });
    return { pJ, pN };
  }
  createPagesSociosDirectos(socios) {
    let pages = [[{ tipo_persona: 'tituloD' }]];
    let numPagesAdd = 0;
    let index = 0;
    let maxPixels = 1200;
    let socioJ: any = 150;
    // if (
    //   this.form.Informacion_cliente.datos_generales
    //     .estructura_sin_personeria_juridica == 'SI'
    // ) {
    //   socioJ = 150;
    // } else {
    //   socioJ = 125;
    // }

    const socioN = 380;

    while (socios.pJ.length > 0) {
      if (maxPixels >= 160) {
        agregarSociosAlResultado(
          socios.pJ[0],
          index,
          socioJ,
          socios.pJ[0].tipo_persona,
        );
      } else {
        index++;
        maxPixels = 1200;
        numPagesAdd++;
        pages.push([]);
      }
    }
    numPagesAdd++;
    while (socios.pN.length > 0) {
      if (maxPixels >= 390) {
        agregarSociosAlResultado(
          socios.pN[0],
          index,
          socioN,
          socios.pN[0].tipo_persona,
        );
      } else {
        index++;
        pages.push([]);
        numPagesAdd++;
        maxPixels = 1200;
      }
    }

    function agregarSociosAlResultado(socio, i, pixelsSocio, type) {
      // const cantidadASplice = Math.min(socios.length, espacio);
      if (type == 'juridica' || type == 'sin juridica') {
        socios.pJ.shift();
        pages[i].push(socio);
        maxPixels -= pixelsSocio;
      } else if (type == 'natural') {
        socios.pN.shift();
        pages[i].push(socio);
        maxPixels -= pixelsSocio;
      } else if (type == 'tituloJ') {
        socios.pJ.shift();
        pages[i].push(socio);
        maxPixels -= 14;
      } else if (type == 'tituloN') {
        socios.pN.shift();
        pages[i].push(socio);
        maxPixels -= 14;
      }
    }
    this.pagesSocioDirecto = pages;
    this.totalNumPages = this.totalNumPages + numPagesAdd - 1;
    this.totalNumPagesSociosDirectos = pages.length;
  }
  calculateSociosIndirectos(sociosIndirectos) {
    let totalNiveles = sociosIndirectos.length - 1;
    let sociosJuridicos: any = [];
    let sociosIndirectosOrdenados: any = [];
    for (let index = 0; index <= totalNiveles; index++) {
      if (index == 0) {
        this.form.socios_accionistas.socios_directos.forEach((socio: any) => {
          sociosJuridicos.push([]);
          if (
            socio.tipo_persona == 'juridica' ||
            socio.tipo_persona == 'sin juridica'
          ) {
            if (
              socio.participacion_capital >= 5 ||
              socio.beneficios_rendimientos_utilidades >= 5
            ) {
              sociosJuridicos[index].push(socio);
            }
          }
        });
      } else {
        this.form.socios_accionistas.socios_indirectos[
          index - 1
        ].socios.forEach((socio: any) => {
          sociosJuridicos.push([]);
          if (
            socio.tipo_persona == 'juridica' ||
            socio.tipo_persona == 'sin juridica'
          ) {
            if (
              socio.participacion_capital >= 5 ||
              socio.beneficios_rendimientos_utilidades >= 5
            ) {
              sociosJuridicos[index].push(socio);
            }
          }
        });
      }
    }
    for (let index = 0; index <= totalNiveles; index++) {
      for (let x = 0; x < sociosJuridicos[index].length; x++) {
        let socios = [];
        sociosIndirectos[index].socios.forEach((socio) => {
          if (socio.socio_superior == sociosJuridicos[index][x].razon_social) {
            socios.push(socio);
          }
        });
        let sociosJyN = this.separarSocios(socios);
        sociosIndirectosOrdenados.push({
          nivel: sociosIndirectos[index].nivel,
          socio_superio: sociosJuridicos[index][x].razon_social,
          sociosJyN: sociosJyN,
        });
      }
    }

    this.checkPagesSociosIndirectos(sociosIndirectosOrdenados);
  }
  checkPagesSociosIndirectos(sociosIndirectosOrdenados) {
    let totalSocios = sociosIndirectosOrdenados;
    let pages: any = [[{ tipo_persona: 'tituloD' }]];
    let data: any;
    let i = 0;
    let maxPixels = 1150;
    for (let index = 0; index < sociosIndirectosOrdenados.length; index++) {
      data = this.createPagesSociosIndirectos(
        sociosIndirectosOrdenados[index].sociosJyN,
        pages,
        maxPixels,
        sociosIndirectosOrdenados[index].nivel,
        sociosIndirectosOrdenados[index].socio_superio,
        i,
      );
      maxPixels = data.maxPixels;
      i = data.index;
    }
    if (data) {
      if (data.numPagesAdd) {
        if (this.pagesSocioDirecto.length > 1) {

          this.totalNumPages = this.totalNumPages + data.numPagesAdd + 1;
        } else {
          this.totalNumPages = this.totalNumPages + data.numPagesAdd;
        }
      }
    }

  }

  createPagesSociosIndirectos(
    socios,
    tPages,
    maxPixels,
    nivel,
    socioSuperio,
    indexd,
  ) {
    let pages = tPages;
    let numPagesAdd = 1;
    let index = indexd;
    const socioJ = 150;
    const socioN = 380;
    if (maxPixels - 46 < 160) {
      index++;
      pages.push([]);

      numPagesAdd++;
      maxPixels = 1200;
    }
    let titulo = {
      tipo_persona: 'tituloNyS',
      nivel: nivel,
      socio_superio: socioSuperio,
    };
    pages[index].push(titulo);
    maxPixels = maxPixels - 50;

    while (socios.pJ.length > 0) {
      if (maxPixels >= 160) {
        agregarSociosAlResultado(
          socios.pJ[0],
          index,
          150,
          socios.pJ[0].tipo_persona,
        );
      } else {
        index++;
        maxPixels = 1150;
        numPagesAdd++;
        pages.push([]);
      }
    }
    numPagesAdd++;
    while (socios.pN.length > 0) {
      if (maxPixels >= 390) {
        agregarSociosAlResultado(
          socios.pN[0],
          index,
          380,
          socios.pN[0].tipo_persona,
        );
      } else {
        index++;
        numPagesAdd++;
        maxPixels = 1150;
        pages.push([]);
      }
    }

    function agregarSociosAlResultado(socio, i: any, pixelsSocio, type) {
      // const cantidadASplice = Math.min(socios.length, espacio);
      if (type == 'juridica' || type == 'sin juridica') {
        socios.pJ.shift();
        pages[i].push(socio);
        maxPixels -= pixelsSocio;
      } else if (type == 'natural') {
        socios.pN.shift();
        pages[i].push(socio);
        maxPixels -= pixelsSocio;
      } else if (type == 'tituloJ') {
        socios.pJ.shift();
        pages[i].push(socio);
        maxPixels -= 25;
      } else if (type == 'tituloN') {
        socios.pN.shift();
        pages[i].push(socio);
        maxPixels -= 25;
      }
    }
    this.pagesSocioIndirecto = pages;
    return { maxPixels, numPagesAdd, index };
  }
  async getFormData() {
    const form = await this.formService.getForms();
    if (form) {
      let index = form.forms.findIndex((f: any) => f.id === this.formCode);

      if (form.forms[index]) {

        // this.status = 'valid';
        this.form = form.forms[index]
        // this.form = form;
        this.nombreRepresentante =
          this.form.Informacion_cliente.representante_legal.primer_nombre +
          ' ' +
          this.form.Informacion_cliente.representante_legal.segundo_nombre +
          ' ' +
          this.form.Informacion_cliente.representante_legal.primer_apellido +
          ' ' +
          this.form.Informacion_cliente.representante_legal.segundo_apellido;
        this.calculateSocios();
      }

    }
  }

  // async generarPDF() {
  //   await this.getFormData();
  //   this.loader = true;
  //   // this.formService.saveFormDataFId(this.form, this.formCode, true);

  //   const pdf = new jsPDF('p', 'px', [816, 1344]);
  //   const options = {
  //     margin: {
  //       top: 10,
  //       bottom: 10,
  //     },
  //   };
  //   const addPageNumbers = (pdf) => {
  //     const pageCount = pdf.internal.getNumberOfPages();
  //     for (let i = 1; i <= pageCount - 1; i++) {
  //       pdf.setPage(i);
  //       pdf.setFontSize(10);
  //       pdf.text(`Pagina ${i} / ${pageCount - 1}`, pdf.internal.pageSize.getWidth() - 10, pdf.internal.pageSize.getHeight() - 10, {
  //         align: 'right'
  //       });
  //     }
  //   };
  //   const content = this.pagina1.nativeElement;
  //   const name = this.form.Informacion_cliente.datos_generales.razon_social;
  //   await new Promise<void>((resolve, reject) => {
  //     pdf.html(content, {
  //       callback: function () {
  //         addPageNumbers(pdf);
  //         pdf.save('Formulario_vinculacion_' + name);
  //         resolve();
  //       },
  //       autoPaging: 'text',

  //       margin: [0, 10, 0, 0],
  //       html2canvas: {
  //         scale: 1,
  //       },
  //     });
  //   });

  //   this.loader = false;
  //   // ...
  // }
  // generarPDF(): void {
  //   const content = this.pagina1;
  //   html2pdf(content).save('documento.pdf');
  // }

  async generarPDF() {
    this.loader = true;

    const pdf = new jsPDF('p', 'px', [816, 1344]);

    const addPageNumbers = (pdf) => {
      const pageCount = pdf.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount - 1; i++) {
        pdf.setPage(i);
        pdf.setFontSize(10);
        pdf.text(`Pagina ${i} / ${pageCount - 1}`, pdf.internal.pageSize.getWidth() - 10, pdf.internal.pageSize.getHeight() - 10, {
          align: 'right'
        });
      }
    };

    const preloadImages = () => {
      return new Promise<void>((resolve) => {
        const images = Array.from(document.images);
        let loaded = 0;
        images.forEach((image) => {
          if (image.complete) {
            loaded++;
            if (loaded === images.length) resolve();
          } else {
            image.onload = () => {
              loaded++;
              if (loaded === images.length) resolve();
            };
          }
        });
      });
    };

    const content = this.pagina1.nativeElement;
    await preloadImages(); // Pre-cargar las imágenes

    await new Promise<void>((resolve, reject) => {
      pdf.html(content, {
        callback: function () {
          try {
            addPageNumbers(pdf);
            pdf.save('Formulario_vinculacion_' + 'nombre_del_cliente');
            resolve();
          } catch (error) {
            reject(error);
          }
        },
        margin: [0, 10, 0, 0],
        html2canvas: {
          scale: 1,
        },
      });
    }).catch((error) => {
      console.error("Error al generar el PDF", error);
    });

    this.loader = false;
  }
}
