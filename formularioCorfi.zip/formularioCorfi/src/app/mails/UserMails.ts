// // import settings from "../config/settings";

// // const nodemailer = require("nodemailer");

// // const createMailTransporter = () => {
// //   const transporter = nodemailer.createTransport({
// //     host: emailAdmin.HOST,

// //     port: emailAdmin.PORT,
// //     auth: {
// //       user: emailAdmin.EMAIL,
// //       pass: emailAdmin.PASS,
// //     },
// //   });
// //   return transporter;
// // };

// const sendMailCodeValid = (
//   userData: any,
//   code: string
//   // urlDom: string
// ) => {
//   const mailOptions = {
//     from: emailAdmin.EMAIL, // Remitente del correo
//     to: userData.user_email, // Destinatario del correo
//     subject: "Codigo de verificacion Corficolombiana",
//     html: `
//     <p>Hola 👋 ${userData.firstname}, verifica tu correo Utilizando el siguiente codigo...</p>
//     <br>
//     <p>Codigo</p>
//     <p>${code}</p>
//     `,
//   };
//   const transporter = createMailTransporter();
//   transporter.sendMail(mailOptions, (error: any, info: any) => {
//     if (error) {
//       console.error("Error al enviar el correo:", error);
//     } else {
//       console.log("Correo enviado:", info.response);
//     }
//   });
// };
// const sendMailChangePassword = (
//   userData: any,
//   url: string
//   // urlDom: string
// ) => {
//   const mailOptions = {
//     from: emailAdmin.EMAIL, // Remitente del correo
//     to: userData.user_email, // Destinatario del correo
//     subject: "Cambiar contraseña (correo electronico Corficolombiana)",
//     html: `
//     <p>Hola 👋 ${userData.firstname}, Ingresa tu nueva contraseña en el siguiente link...</p>
//     <br>
//     <a href="${url}/${userData.emailToken}"></a>
//     `,
//   };
//   const transporter = createMailTransporter();
//   transporter.sendMail(mailOptions, (error: any, info: any) => {
//     if (error) {
//       console.error("Error al enviar el correo:", error);
//     } else {
//       console.log("Correo enviado:", info.response);
//     }
//   });
// };
// const sendMailEmailValid = (
//   userData: any,
//   url: string
//   // urlDom: string
// ) => {
//   const mailOptions = {
//     from: emailAdmin.EMAIL, // Remitente del correo
//     to: userData.user_email, // Destinatario del correo
//     subject: "Verificacion de correo electronico Corficolombiana",
//     html: `
//     <p>Hola 👋 ${userData.firstname}, verifica tu correo en el siguiente link...</p>
//     <br>
//     <a href="${url}/${userData.emailToken}"></a>
//     `,
//   };
//   const transporter = createMailTransporter();
//   transporter.sendMail(mailOptions, (error: any, info: any) => {
//     if (error) {
//       console.error("Error al enviar el correo:", error);
//     } else {
//       console.log("Correo enviado:", info.response);
//     }
//   });
// };
// module.exports = {
//   sendMailCodeValid,
//   sendMailEmailValid,
//   sendMailChangePassword,
// };
