export const primaryButtons = ['#9EC72D', '#00185f'];
