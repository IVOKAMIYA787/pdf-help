import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pop-up-simple',
  templateUrl: './pop-up-simple.component.html',
  styleUrls: ['./pop-up-simple.component.scss'],
})
export class PopUpSimpleComponent implements OnInit {
  // @Input() showPopUp = false;
  @Input() Messagge = {
    titulo: '',
    descripcion: '',
    tipe: '',
  };

  @Output() showPopUp = new EventEmitter<boolean>();
  constructor() {}

  ngOnInit(): void {}
  onClose() {
    // this.showPopUp = false;
    this.showPopUp.emit(false);
  }
}
