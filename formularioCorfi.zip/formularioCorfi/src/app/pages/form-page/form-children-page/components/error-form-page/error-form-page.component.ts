import { Component } from '@angular/core';

@Component({
  selector: 'app-error-form-page',
  templateUrl: './error-form-page.component.html',
  styleUrls: ['./error-form-page.component.scss'],
})
export class ErrorFormPageComponent {}
