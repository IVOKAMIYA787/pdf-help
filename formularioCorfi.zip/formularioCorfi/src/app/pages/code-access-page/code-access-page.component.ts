import { Component } from '@angular/core';

import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { CheckCodeGuard } from '../../guards/check-code.guard';
@Component({
  selector: 'app-code-access-page',
  templateUrl: './code-access-page.component.html',
  styleUrls: ['./code-access-page.component.scss'],
})
export class CodeAccessPageComponent {
  code = '';

  ngForm = NgForm;
  submitInvalid = false;
  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}
  onSubmit(form: NgForm) {
    if (form.valid) {
      this.submitInvalid = false;
      const ifCode = this.authService.checkCode(this.code);

      if (ifCode) {
        this.router.navigate(['/form']);
      } else {
        alert('Codigo incorrecto');
      }
    } else {
      this.submitInvalid = true;
    }
  }
}
