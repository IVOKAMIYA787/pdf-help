import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConocimientoUsuarioComponent } from './conocimiento-usuario.component';

describe('ConocimientoUsuarioComponent', () => {
  let component: ConocimientoUsuarioComponent;
  let fixture: ComponentFixture<ConocimientoUsuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConocimientoUsuarioComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ConocimientoUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
