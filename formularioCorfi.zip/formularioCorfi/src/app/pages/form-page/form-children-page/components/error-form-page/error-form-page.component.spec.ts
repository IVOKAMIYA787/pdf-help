import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorFormPageComponent } from './error-form-page.component';

describe('ErrorFormPageComponent', () => {
  let component: ErrorFormPageComponent;
  let fixture: ComponentFixture<ErrorFormPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ErrorFormPageComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorFormPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
