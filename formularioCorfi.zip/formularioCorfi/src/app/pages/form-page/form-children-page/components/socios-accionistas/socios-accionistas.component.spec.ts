import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SociosAccionistasComponent } from './socios-accionistas.component';

describe('SociosAccionistasComponent', () => {
  let component: SociosAccionistasComponent;
  let fixture: ComponentFixture<SociosAccionistasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SociosAccionistasComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SociosAccionistasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
