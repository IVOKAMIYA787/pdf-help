import { Component, EventEmitter, OnInit, Input, Output } from '@angular/core';
import { NgForm } from '@angular/forms';

import * as XLSX from 'xlsx';
import { countries, Country } from 'countries-list';
import { FormService } from 'src/app/services/form.service';
import { formData } from 'src/app/utils/form.utils';
@Component({
  selector: 'app-conocimiento-usuario-part2',
  templateUrl: './conocimiento-usuario-part2.component.html',
  styleUrls: [
    './conocimiento-usuario-part2.component.scss',
    '../conocimiento-usuario/conocimiento-usuario.component.scss',
  ],
})
export class ConocimientoUsuarioPart2Component implements OnInit {
  paises: { Nombre: string | any; Codigo: string }[] = [];
  @Output() step = new EventEmitter<string>();
  submitInvalid = false;
  @Input() formId = ''
  @Input() page2Valide = false;
  @Input() form = formData;
  ShowPopUp = false;
  MessaggePopUp = {
    titulo: 'titulo',
    descripcion: 'texto explicativo',
    tipe: 'simple',
  };
  selectOperacionesMoneda = [
    '',
    'Importaciones',
    'Exportaciones',
    'Transferencias',
    'Pagos de servicios',
    'Préstamos M/Ext',
    'Cambio de Divisas',
    'Inversiones M/Ext',
    'Ingresos por donaciones',
    'Otros',
  ];
  selectTipoProducto = [
    '',
    'CDTs',
    'Otros Titulos del Gobierno',
    'Bonos de Deuda Pública',
    'Crédito',
    'Cuenta de ahorro',
    'Factoring',
    'Repos/Simultaneas',
    'Notas estructuradas',
    'Cartera Colectiva',
    'Fondos de pensiones',
    'Fondos de Valores',
    'Cuentas Corrientes',
    'Leasing',
    'Bonos Corporativos',
    'Acciones',
    'TES',
    'Otro Producto ',
  ];
  selectOrigenBienes = [
    '',
    'AHORROS LABORALES',
    'ACTIVIDAD ECONOMICA',
    'APORTES SOCIOS',
    'COMPRA VENTA DE BIENES',
    'DIVIDENDOS Y PARTICIPACIONES',
    'DONACION DE PARTICULARES',
    'EJERCICIO ACT PROFESIONAL',
    'EXCEDENTES DE CAPITAL',
    'GANANCIA OCASIONAL ',
    'INGRESOS POR  DIVIDENDOS',
    'INGRESOS POR SALARIO',
    'LIQUIDACIÓN DE SOCIEDAD',
    'LIQUIDACIÓN LABORAL',
    'MESADA PADRES O HIJOS',
    'NEGOCIO PROPIO',
    'OBSEQUIO DE FAMILIARES',
    'OBJETO SOCIAL DEL NEGOCIO',
    'PAGO DE SEGUROS O INDEMNIZACION',
    'PARTICIPACIÓN EN SOCIEDADES',
    'PENSION',
    'PREMIO  DE LOTERIA',
    'AHORROS FAMILIARES',
    'PRESTAMOS DE ENTIDADES FINANCIERAS',
    'RENDIMIENTOS FINANCIEROS',
    'RENTA',
    'RENTAS DE CAPITAL',
    'RETIRO DE CESANTIAS',
    'RIFAS',
    'TRANSFERENCIA DEL EXTERIOR',
    'VENTAS DE ACCIONES',
    'VENTAS DE ACTIVOS',
    'VENTA DE APARTAMENTO',
    'VENTA DE BODEGA',
    'VENTA DE  CASA',
    'ARRENDAMIENTOS',
    'VENTA DE EDIFICIO',
    'VENTA DE FINCA',
    'VENTA DE LOTE',
    'VENTA DE OFICINA',
    'VENTA DE PRODUCTOS AGRICOLAS',
    'VENTA DE TITULOS',
    'VENTA DE VEHICULO',
    'VENTA OTROS ACTIVOS',
    'VENTA DE VALORES',
    'POLIZAS',
    'SEGUROS',
    'COMERCIALIZACION SEMOVIENTES',
    'DONACIONES DE  EMPRESAS',
    'DONACIONES DE PARTICULARES',
    'EXCEDENTES DE CAPITAL',
    'HERENCIAS',
    'HONORARIOS POR ASESORIAS',
  ];
  constructor(private formService: FormService) { }

  ngOnInit(): void {
    this.getPaises();
  }
  volverStep() {
    this.step.emit('1');
  }
  showActivePopUp(status: boolean) {
    this.ShowPopUp = status;
  }

  validateForm(step1Form: NgForm) {
    if (step1Form.valid) {
      this.submitInvalid = false;

      this.form.active_pages.page2 = true;
      // this.formService.saveForm(this.form);
      this.formService.saveFormDataFId(this.form, this.formId, true);

      this.step.emit('3');
    } else {
      this.submitInvalid = true;
      this.showActivePopUp(true);
      this.MessaggePopUp.titulo = 'Alerta';
      this.MessaggePopUp.descripcion =
        'Tienes campos sin diligenciar, verifica antes de continuar';
      this.MessaggePopUp.tipe = 'alert';
    }
  }
  getPaises() {
    // this.paises = Object.keys(countries).map((code) => {
    //   return {
    //     name: (countries as { [code: string]: Country })[code].name,
    //     code: code,
    //   };
    // });
    const fileUrl = './assets/paises.xlsx';
    fetch(fileUrl)
      .then((response) => response.arrayBuffer())
      .then((arrayBuffer) => {
        if (arrayBuffer) {
          const workbook = XLSX.read(new Uint8Array(arrayBuffer), {
            type: 'array',
          });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          this.paises = XLSX.utils.sheet_to_json(worksheet, {
            raw: true,
          });
          // Los datos del archivo Excel están disponibles en this.excelData
        } else {
          console.error('No se pudo cargar el archivo Excel.');
        }
      })
      .catch((error) => {
        console.error('Error al cargar el archivo Excel:', error);
      });
  }
}
