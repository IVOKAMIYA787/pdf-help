import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-socios-accionistas',
  templateUrl: './socios-accionistas.component.html',
  styleUrls: ['./socios-accionistas.component.scss'],
})
export class SociosAccionistasComponent implements OnInit {
  existPersonaJuridica: any;
  stepNavigator = -1;
  formCode: any = '';
  @Input() form: any;

  @Output() step = new EventEmitter<string>();
  constructor(private _route: ActivatedRoute) {
    this.formCode = this._route.snapshot.paramMap.get('code');
  }
  ngOnInit(): void {
    this.validateSociosJuridicos();

    if (
      this.form.socios_accionistas.socios_indirectos.length > 1 &&
      this.form.formato_anexo.PEI == false
    ) {
      this.stepNavigator =
        this.form.socios_accionistas.socios_indirectos.length - 1;
    }
  }
  changeStep(step: string) {
    this.step.emit('4');
  }
  añadirNivel() { }
  changeNavigate(num: any) {
    this.stepNavigator = num;
    this.validateSociosJuridicos();
  }

  sociosData = {
    sj: [
      {
        id: '',
        porcentaje: 0,
      },
    ],
    desglose: [
      {
        id1: '',
        id2: '',
      },
    ],
  };
  guardarSocio(socioAdd: { id: any; porcentaje: number; id2?: any }) {
    if (socioAdd.id2) {
      this.sociosData.sj.push({
        id: socioAdd.id,
        porcentaje: socioAdd.porcentaje,
      });
      this.sociosData.desglose.push({ id1: socioAdd.id, id2: socioAdd.id2 });
    } else {
      this.sociosData.sj.push({
        id: socioAdd.id,
        porcentaje: socioAdd.porcentaje,
      });
    }
  }
  verifyDesglose() {
    let sociosNum = 0;
    this.sociosData.sj.forEach((socioJuridico) => {
      if (socioJuridico.porcentaje >= 5) {
        const exist = this.sociosData.desglose.find(
          (desglose) => desglose.id2 == socioJuridico.id,
        );
        if (!exist) {
          sociosNum = sociosNum + 1;
        }
      }
    });
    return sociosNum;
  }
  validateSociosJuridicos() {
    const exist = this.form.socios_accionistas.socios_directos.some((socio) => {
      return (
        socio.tipo_persona == 'juridica' && socio.participacion_capital > 5
      );
    });
    this.existPersonaJuridica = exist;
  }
}
