import { Component } from '@angular/core';

@Component({
  selector: 'app-beneficiario-no',
  templateUrl: './beneficiario-no.component.html',
  styleUrls: ['./beneficiario-no.component.scss']
})
export class BeneficiarioNoComponent {

}
