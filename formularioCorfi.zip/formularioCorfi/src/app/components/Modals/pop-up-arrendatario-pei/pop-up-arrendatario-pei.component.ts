import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-pop-up-arrendatario-pei',
  templateUrl: './pop-up-arrendatario-pei.component.html',
  styleUrls: ['./pop-up-arrendatario-pei.component.scss'],
})
export class PopUpArrendatarioPEIComponent {
  @Input() status = false;
  @Input() form: any;

  @Output() saveData = new EventEmitter<any>();
  @Output() closedModalPei = new EventEmitter<boolean>();
  submitInvalid = false;
  closedModal() {
    this.closedModalPei.emit(false);
    this.status = false;
  }
  validText(request: string) {
    if (request == 'si') {
      this.form.formato_anexo.active = false;

      this.form.formato_anexo.PEI = false;
      this.closedModal();
      this.saveData.emit(this.form);
    } else {
      this.form.formato_anexo.active = false;
      this.form.formato_anexo.PEI = true;
      this.closedModal();

      this.saveData.emit(this.form);
    }
  }
}
