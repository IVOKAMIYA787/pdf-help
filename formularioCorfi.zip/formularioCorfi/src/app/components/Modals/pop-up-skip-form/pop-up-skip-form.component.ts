import { Component } from '@angular/core';

@Component({
  selector: 'app-pop-up-skip-form',
  templateUrl: './pop-up-skip-form.component.html',
  styleUrls: ['./pop-up-skip-form.component.scss'],
})
export class PopUpSkipFormComponent {
  status = false;
}
